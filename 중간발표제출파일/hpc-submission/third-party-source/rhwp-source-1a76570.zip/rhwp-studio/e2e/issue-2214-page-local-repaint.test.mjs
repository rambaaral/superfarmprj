/**
 * Issue #2214 focused GREEN regression, #3815 stack integration, and optional diagnostic.
 *
 * The default path is a focused HWP/HWPX regression that verifies the 56th
 * cell-flow boundary, pre-cursor pagination, exact tree/caret state, and the
 * absence of an additional flush through the 62nd input. The original
 * timeline/PNG controls remain available behind --diagnose. `--continuous-only` is the local
 * production-WASM + Chrome integration gate for #3815 on top of #3937/#3822; CI only syntax-checks
 * this browser scenario, so its measured timings and page/revision assertions are local evidence.
 *
 * [#2430] 한양·휴먼 HFT ASCII 실측 교정으로 대상 셀의 줄 채움 임계가 44→56,
 * 관측 범위가 50→62 로 이동했다 (native 계약: tests/issue_2214_page_local_repaint.rs
 * 의 cell_flow_transition_baseline 이 0..62 전 구간에서 경계 56 단일 관측).
 *
 * Usage:
 *   node e2e/issue-2214-page-local-repaint.test.mjs --mode=headless
 *   node e2e/issue-2214-page-local-repaint.test.mjs --mode=headless --runs=1  # local smoke
 *   node e2e/issue-2214-page-local-repaint.test.mjs --mode=headless --continuous-only
 *   node e2e/issue-2214-page-local-repaint.test.mjs --mode=headless --review-only
 *   node e2e/issue-2214-page-local-repaint.test.mjs --mode=headless --diagnose
 *   node e2e/issue-2214-page-local-repaint.test.mjs --mode=headless --diagnose \
 *     --formats=hwp --runs=1
 */

import assert from 'node:assert/strict';
import crypto from 'node:crypto';
import { mkdirSync, readFileSync, writeFileSync } from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import pixelmatch from 'pixelmatch';
import { PNG } from 'pngjs';
import {
  closeBrowser,
  closePage,
  createPage,
  launchBrowser,
  loadApp,
} from './helpers.mjs';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const REPO_ROOT = path.resolve(__dirname, '../..');
const OUTPUT_ROOT = process.env.ISSUE2214_OUTPUT_ROOT
  ?? path.join(REPO_ROOT, 'output/poc/task2214/stage4');
const TARGET = Object.freeze({
  sectionIndex: 0,
  paragraphIndex: 5,
  charOffset: 130,
  parentParaIndex: 0,
  controlIndex: 2,
  cellIndex: 2,
  cellParaIndex: 5,
  cellPath: [{ controlIndex: 2, cellIndex: 2, cellParaIndex: 5 }],
});
const MAX_INSERTS = 128;
const CONTINUOUS_WRAP_MAX_INSERTS = 160;
const CONTINUOUS_WRAP_TAIL_INPUTS = 4;
const CONTINUOUS_INPUT_MIN_GAP_MS = 8;

const SAMPLES = Object.freeze({
  hwp: path.join(REPO_ROOT, 'samples/issue1949_giant_cell_nested_tables_perf.hwp'),
  hwpx: path.join(REPO_ROOT, 'samples/issue1949_giant_cell_nested_tables_perf.hwpx'),
});

function cliValue(name, fallback) {
  const arg = process.argv.find((value) => value.startsWith(`--${name}=`));
  return arg ? arg.slice(name.length + 3) : fallback;
}

function sanitizeLabel(value) {
  return String(value).replace(/[^a-zA-Z0-9._-]+/g, '-');
}

function sha256(buffer) {
  return crypto.createHash('sha256').update(buffer).digest('hex');
}

function percentile(values, quantile) {
  if (!values.length) return null;
  const sorted = [...values].sort((a, b) => a - b);
  const index = Math.min(sorted.length - 1, Math.max(0, Math.ceil(sorted.length * quantile) - 1));
  return sorted[index];
}

function summarizeDurations(values) {
  return {
    count: values.length,
    p50Ms: percentile(values, 0.5),
    p95Ms: percentile(values, 0.95),
    maxMs: values.length ? Math.max(...values) : null,
  };
}

function traceDurations(trace, type) {
  return trace.events
    .filter((event) => event.type === type && typeof event.durationMs === 'number')
    .map((event) => event.durationMs);
}

function writeJson(filePath, value) {
  mkdirSync(path.dirname(filePath), { recursive: true });
  writeFileSync(filePath, `${JSON.stringify(value, null, 2)}\n`);
}

async function waitTwoRafs(page) {
  await page.evaluate(() => new Promise((resolve) => {
    requestAnimationFrame(() => requestAnimationFrame(resolve));
  }));
}

async function delay(page, ms) {
  await page.evaluate((value) => new Promise((resolve) => setTimeout(resolve, value)), ms);
}

async function clickBlockingModalChoice(page) {
  return page.evaluate(() => {
    const allowed = new Set(['그대로 보기', '대체 글꼴로 보기']);
    const buttons = Array.from(document.querySelectorAll('button'));
    const button = buttons.find((candidate) => {
      const label = candidate.textContent?.trim() ?? '';
      const style = getComputedStyle(candidate);
      return allowed.has(label) && style.display !== 'none' && style.visibility !== 'hidden';
    });
    if (!button) return null;
    const label = button.textContent?.trim() ?? '';
    button.click();
    return label;
  });
}

async function openDocumentThroughApp(page, format, bytes) {
  const fileName = path.basename(SAMPLES[format]);
  const encoded = bytes.toString('base64');
  const requestId = `issue2214-${format}-${crypto.randomUUID()}`;

  await page.evaluate(({ base64, name, id }) => {
    const binary = atob(base64);
    const payload = new Uint8Array(binary.length);
    for (let i = 0; i < binary.length; i += 1) payload[i] = binary.charCodeAt(i);

    window.__issue2214LoadResult = null;
    const off = window.__eventBus.on('open-document-bytes:done', (result) => {
      if (result?.requestId !== id) return;
      off();
      window.__issue2214LoadResult = result;
    });
    window.__eventBus.emit('open-document-bytes', {
      bytes: payload,
      fileName: name,
      fileHandle: null,
      skipUnsavedGuard: true,
      requestId: id,
    });
  }, { base64: encoded, name: fileName, id: requestId });

  const deadline = Date.now() + 90_000;
  const modalChoices = [];
  let result = null;
  while (Date.now() < deadline) {
    const choice = await clickBlockingModalChoice(page);
    if (choice) modalChoices.push(choice);
    result = await page.evaluate(() => window.__issue2214LoadResult);
    if (result) break;
    await new Promise((resolve) => setTimeout(resolve, 100));
  }
  assert.ok(result, `${format}: open-document-bytes:done timeout`);
  assert.equal(result.ok, true, `${format}: document load failed: ${result.error ?? 'unknown'}`);

  await page.evaluate(() => document.fonts.ready);
  await waitTwoRafs(page);
  const state = await page.evaluate(() => {
    const wasm = window.__wasm;
    const input = window.__inputHandler;
    const canvasView = window.__canvasView;
    return {
      sourceFormat: wasm.getSourceFormat(),
      pageCount: wasm.pageCount,
      inputActive: input.isActive(),
      hasPageZeroCanvas: Boolean(canvasView.canvasPool.getCanvas(0)),
      fontsStatus: document.fonts.status,
      devicePixelRatio: window.devicePixelRatio,
      zoom: canvasView.viewportManager.getZoom(),
      viewport: { width: window.innerWidth, height: window.innerHeight },
    };
  });
  assert.equal(state.sourceFormat, format, `${format}: source format mismatch`);
  assert.equal(state.pageCount, 115, `${format}: expected 115 pages`);
  assert.equal(state.inputActive, true, `${format}: input handler inactive`);
  assert.equal(state.hasPageZeroCanvas, true, `${format}: page zero canvas missing`);
  assert.equal(state.fontsStatus, 'loaded', `${format}: fonts are not ready`);
  return { ...state, modalChoices };
}

async function moveToTarget(page) {
  const position = await page.evaluate((target) => {
    const input = window.__inputHandler;
    input.cursor.clearSelection();
    input.cursor.moveTo(target);
    input.cursor.resetPreferredX();
    input.updateCaret();
    input.focus();
    return {
      position: input.cursor.getPosition(),
      rect: input.cursor.getRect(),
      focused: document.activeElement === input.textarea,
    };
  }, TARGET);
  assert.equal(position.focused, true, 'hidden textarea was not focused');
  assert.equal(position.position.charOffset, TARGET.charOffset, 'target char offset mismatch');
  assert.equal(position.position.cellParaIndex, TARGET.cellParaIndex, 'target cell paragraph mismatch');
  return position;
}

async function dispatchInputSynchronously(page, text = '1') {
  return page.evaluate((value) => {
    const input = window.__inputHandler;
    input.textarea.value = value;
    const startedAt = performance.now();
    input.textarea.dispatchEvent(new InputEvent('input', {
      bubbles: true,
      inputType: 'insertText',
      data: value,
    }));
    const wasm = window.__wasm;
    const position = input.cursor.getPosition();
    const length = wasm.getCellParagraphLength(0, 0, 2, 2, 5);
    const modelText = wasm.getTextInCell(0, 0, 2, 2, 5, 0, length);
    return {
      durationMs: performance.now() - startedAt,
      cursor: position,
      modelLength: length,
      modelTail: modelText.slice(-40),
      lineInfo: wasm.getLineInfoInCell(0, 0, 2, 2, 5, position.charOffset),
      pending: input.hasDeferredPaginationPending(),
    };
  }, text);
}

async function readLineCount(page) {
  return page.evaluate(() => {
    const input = window.__inputHandler;
    const offset = input.cursor.getPosition().charOffset;
    return window.__wasm.getLineInfoInCell(0, 0, 2, 2, 5, offset).lineCount;
  });
}

async function typeKeyboardOnes(page, count) {
  const durations = [];
  for (let i = 0; i < count; i += 1) {
    const startedAt = performance.now();
    await page.keyboard.type('1');
    durations.push(performance.now() - startedAt);
  }
  return durations;
}

async function restoreTrace(page) {
  await page.evaluate(() => {
    const trace = window.__issue2214Trace;
    if (!trace) return;
    for (const restore of trace.restores ?? []) restore();
    for (const off of trace.offs ?? []) off();
    window.__issue2214Trace = null;
  });
}

async function installTrace(page) {
  await restoreTrace(page);
  await page.evaluate(() => {
    const trace = {
      startedAt: performance.now(),
      events: [],
      restores: [],
      offs: [],
      sequence: 0,
    };
    const record = (type, detail = {}) => {
      trace.events.push({
        sequence: ++trace.sequence,
        type,
        atMs: performance.now() - trace.startedAt,
        ...detail,
      });
    };
    const wrap = (object, name, type, describeArgs = () => ({}), describeResult = () => ({})) => {
      const original = object?.[name];
      if (typeof original !== 'function') return;
      object[name] = function issue2214Wrapped(...args) {
        const startedAt = performance.now();
        let result;
        try {
          result = original.apply(this, args);
          return result;
        } finally {
          record(type, {
            ...describeArgs(args),
            ...describeResult(result),
            durationMs: performance.now() - startedAt,
          });
        }
      };
      trace.restores.push(() => { object[name] = original; });
    };

    const wasm = window.__wasm;
    const input = window.__inputHandler;
    const canvasView = window.__canvasView;
    const renderer = canvasView.pageRenderer;

    const describePaginationResult = (result) => ({
      status: result?.status ?? null,
      revision: result?.revision ?? null,
      fragmentsProcessed: result?.fragmentsProcessed ?? null,
      pageCount: result?.pageCount ?? null,
    });
    wrap(
      wasm,
      'beginDeferredPagination',
      'wasm.beginDeferredPagination',
      (args) => ({ fragmentBudget: args[0] }),
      describePaginationResult,
    );
    wrap(
      wasm,
      'stepDeferredPagination',
      'wasm.stepDeferredPagination',
      (args) => ({ fragmentBudget: args[0] }),
      describePaginationResult,
    );
    wrap(
      wasm,
      'cancelDeferredPagination',
      'wasm.cancelDeferredPagination',
      () => ({}),
      (result) => ({ result }),
    );
    wrap(wasm, 'flushDeferredPagination', 'wasm.flushDeferredPagination', (args) => ({ argsLength: args.length }));
    wrap(input, 'flushDeferredPaginationIfNeeded', 'input.flushDeferredPaginationIfNeeded', (args) => ({
      reason: args[0] ?? 'manual',
      emitChange: args[1] ?? true,
    }), (result) => ({ result }));
    wrap(wasm, 'renderPageToCanvasFiltered', 'wasm.renderPageToCanvasFiltered', (args) => ({
      pageIndex: args[0],
      scale: args[2],
      layerKind: args[3],
    }));
    wrap(wasm, 'insertTextInCellDeferredPagination', 'wasm.insertTextInCellDeferredPagination', (args) => ({
      sectionIndex: args[0],
      parentParaIndex: args[1],
      controlIndex: args[2],
      cellIndex: args[3],
      cellParaIndex: args[4],
      charOffset: args[5],
      textLength: String(args[6] ?? '').length,
    }), (result) => ({
      resultCharOffset: result?.charOffset ?? null,
      paginationDeferred: result?.paginationDeferred ?? null,
      cellFlowChanged: result?.cellFlowChanged ?? null,
    }));
    // [#3412] #3254 가 도입한 단일 호출 치환 경로. IME 조합 갱신은 이제 delete+insert 가
    // 아니라 이 한 번의 replace 로 처리된다 — 계측하지 않으면 흐름이 통째로 안 보인다.
    wrap(wasm, 'replaceTextInCellDeferredPagination', 'wasm.replaceTextInCellDeferredPagination', (args) => ({
      sectionIndex: args[0],
      parentParaIndex: args[1],
      controlIndex: args[2],
      cellIndex: args[3],
      cellParaIndex: args[4],
      charOffset: args[5],
      deleteCount: args[6],
      textLength: String(args[7] ?? '').length,
    }), (result) => ({
      resultCharOffset: result?.charOffset ?? null,
      paginationDeferred: result?.paginationDeferred ?? null,
      cellFlowChanged: result?.cellFlowChanged ?? null,
    }));
    wrap(wasm, 'deleteTextInCellDeferredPagination', 'wasm.deleteTextInCellDeferredPagination', (args) => ({
      sectionIndex: args[0],
      parentParaIndex: args[1],
      controlIndex: args[2],
      cellIndex: args[3],
      cellParaIndex: args[4],
      charOffset: args[5],
      count: args[6],
    }), (result) => ({
      resultCharOffset: result?.charOffset ?? null,
      paginationDeferred: result?.paginationDeferred ?? null,
      cellFlowChanged: result?.cellFlowChanged ?? null,
    }));
    wrap(wasm, 'deleteTextInCell', 'wasm.deleteTextInCell');
    wrap(wasm, 'deleteTextInCellByPath', 'wasm.deleteTextInCellByPath');
    wrap(wasm, 'exportHwp', 'wasm.exportHwp');
    wrap(wasm, 'exportHwpx', 'wasm.exportHwpx');
    wrap(wasm, 'exportHwpWithReport', 'wasm.exportHwpWithReport');
    wrap(wasm, 'exportHwpxWithReport', 'wasm.exportHwpxWithReport');
    wrap(wasm, 'renderPageSvg', 'wasm.renderPageSvg', (args) => ({ pageIndex: args[0] }));
    // [#3412] 인쇄/PDF 경로는 b7234ed07 부터 profile 인자를 받는 변형을 쓴다.
    // 옛 이름만 계측하면 인쇄 barrier 가 렌더 이벤트를 하나도 못 본다.
    wrap(wasm, 'renderPageSvgWithProfile', 'wasm.renderPageSvgWithProfile', (args) => ({
      pageIndex: args[0],
      profile: args[1],
    }));
    wrap(wasm, 'getCursorRectByPathNear', 'wasm.getCursorRectByPathNear', (args) => ({
      sectionIndex: args[0],
      parentParaIndex: args[1],
      charOffset: args[3],
      hintPage: args[4],
    }));
    wrap(wasm, 'getCursorRectByPath', 'wasm.getCursorRectByPath', (args) => ({
      sectionIndex: args[0],
      parentParaIndex: args[1],
      charOffset: args[3],
    }));
    wrap(wasm, 'getCursorRectInCell', 'wasm.getCursorRectInCell', (args) => ({
      sectionIndex: args[0],
      parentParaIndex: args[1],
      controlIndex: args[2],
      cellIndex: args[3],
      cellParaIndex: args[4],
      charOffset: args[5],
    }));
    wrap(input.cursor, 'updateRect', 'CursorState.updateRect');
    wrap(input.cursor, 'moveTo', 'CursorState.moveTo', (args) => ({
      charOffset: args[0]?.charOffset,
      cellParaIndex: args[0]?.cellParaIndex,
    }));
    wrap(input, 'executeOperation', 'InputHandler.executeOperation', (args) => ({
      kind: args[0]?.kind,
      commandType: args[0]?.command?.type,
    }));
    // [#3412] TextMutationEffects 의 필드는 documentPaginationPending/flowChanged 다.
    // 예전 이름(deferredPagination/cellFlowChanged)으로 읽으면 항상 undefined→null 이
    // 기록돼, 아래 단언들이 실제 값과 무관하게 null 로 비교된다.
    wrap(input, 'prepareTextMutationBeforeCursor', 'InputHandler.prepareTextMutationBeforeCursor', (args) => ({
      deferredPagination: args[0]?.documentPaginationPending ?? null,
      cellFlowChanged: args[0]?.flowChanged ?? null,
      paginationCompleted: args[0]?.paginationCompleted ?? null,
    }), (result) => ({ result }));
    wrap(input, 'refreshAfterOperation', 'InputHandler.refreshAfterOperation', (args) => ({
      requested: args[0],
      fallback: args[1],
      commandType: args[2],
    }));
    wrap(input, 'afterPageLocalEdit', 'InputHandler.afterPageLocalEdit');
    wrap(input, 'flushDeferredPaginationForCellOverflow', 'InputHandler.flushDeferredPaginationForCellOverflow',
      () => ({}), (result) => ({ result }));
    wrap(input, 'updateCaret', 'InputHandler.updateCaret');
    wrap(renderer, 'renderPage', 'PageRenderer.renderPage', (args) => ({
      pageIndex: args[0],
      renderScale: args[2],
      zoom: args[3],
      dpr: args[4],
      context: args[5] ?? {},
    }), (result) => ({ result }));
    wrap(canvasView, 'refreshInvalidatedPageNow', 'CanvasView.refreshInvalidatedPageNow', (args) => ({
      pageIndex: args[0],
      context: args[1] ?? {},
    }));

    trace.offs.push(window.__eventBus.on('document-page-invalidated', (payload) => {
      record('event.document-page-invalidated', { payload });
    }));
    trace.offs.push(window.__eventBus.on('document-changed', (payload) => {
      record('event.document-changed', { payload });
    }));
    window.__issue2214Trace = trace;
  });
}

async function collectTrace(page) {
  return page.evaluate(() => {
    const trace = window.__issue2214Trace;
    const events = trace?.events ?? [];
    const count = (type) => events.filter((event) => event.type === type).length;
    return {
      startedAt: trace?.startedAt ?? null,
      events,
      counts: {
        wasmBegin: count('wasm.beginDeferredPagination'),
        wasmStep: count('wasm.stepDeferredPagination'),
        wasmCancel: count('wasm.cancelDeferredPagination'),
        wasmFlush: count('wasm.flushDeferredPagination'),
        inputFlush: count('input.flushDeferredPaginationIfNeeded'),
        invalidation: count('event.document-page-invalidated'),
        documentChanged: count('event.document-changed'),
        filteredRender: count('wasm.renderPageToCanvasFiltered'),
        pageRender: count('PageRenderer.renderPage'),
        refreshNow: count('CanvasView.refreshInvalidatedPageNow'),
        deferredInsert: count('wasm.insertTextInCellDeferredPagination'),
        deferredDelete: count('wasm.deleteTextInCellDeferredPagination'),
        deferredReplace: count('wasm.replaceTextInCellDeferredPagination'),
        immediateDelete: count('wasm.deleteTextInCell'),
        pathDelete: count('wasm.deleteTextInCellByPath'),
        exportHwp: count('wasm.exportHwp'),
        exportHwpx: count('wasm.exportHwpx'),
        renderPageSvg: count('wasm.renderPageSvg') + count('wasm.renderPageSvgWithProfile'),
        cursorRectNear: count('wasm.getCursorRectByPathNear'),
        cursorRect: count('wasm.getCursorRectByPath'),
        cursorRectInCell: count('wasm.getCursorRectInCell'),
        executeOperation: count('InputHandler.executeOperation'),
        prepareTextMutation: count('InputHandler.prepareTextMutationBeforeCursor'),
      },
    };
  });
}

async function resolveCompositedClip(page) {
  const clip = await page.evaluate(() => {
    const canvasView = window.__canvasView;
    const wasm = window.__wasm;
    const canvas = canvasView.canvasPool.getCanvas(0);
    if (!canvas) throw new Error('page zero canvas unavailable');
    const rect = canvas.getBoundingClientRect();
    const tree = wasm.getPageLayerTreeObject(0);
    const ops = [];
    const visit = (node) => {
      if (!node) return;
      if (node.kind === 'group') for (const child of node.children ?? []) visit(child);
      else if (node.kind === 'clipRect') visit(node.child);
      else if (node.kind === 'leaf') ops.push(...(node.ops ?? []));
    };
    visit(tree.root);
    const targets = ops.filter((op) => {
      if (op.type !== 'textRun') return false;
      const key = op.source?.stableSourceKey ?? '';
      return key.startsWith('section:0/para:5/') && key.includes('/cell:0:2:2:5:');
    });
    const minY = targets.length
      ? Math.min(...targets.map((op) => op.bbox?.y ?? 0))
      : (window.__inputHandler.cursor.getRect()?.y ?? 200);
    const scale = tree.pageWidth > 0 ? rect.width / tree.pageWidth : 1;
    const y = Math.max(0, Math.floor(rect.top + (minY - 35) * scale));
    return {
      x: Math.max(0, Math.floor(rect.left)),
      y,
      width: Math.max(1, Math.floor(rect.width)),
      height: 240,
      pageWidth: tree.pageWidth,
      scale,
      targetOpCount: targets.length,
    };
  });
  assert.ok(clip.targetOpCount > 0, 'target paragraph textRun ops were not found');
  return clip;
}

async function resolveCaretGlyphClip(page) {
  return page.evaluate(() => {
    const canvasView = window.__canvasView;
    const cursorRect = window.__inputHandler.cursor.getRect();
    const pageIndex = Number.isInteger(cursorRect?.pageIndex) ? cursorRect.pageIndex : 0;
    const canvas = canvasView.canvasPool.getCanvas(pageIndex);
    if (!canvas || !cursorRect) throw new Error('caret glyph canvas unavailable');
    const canvasRect = canvas.getBoundingClientRect();
    const tree = window.__wasm.getPageLayerTreeObject(pageIndex);
    const scale = tree.pageWidth > 0 ? canvasRect.width / tree.pageWidth : 1;
    const glyphWidth = Math.max(cursorRect.height * 1.5, 24);
    return {
      x: Math.max(0, Math.floor(canvasRect.left + (cursorRect.x - glyphWidth) * scale)),
      y: Math.max(0, Math.floor(canvasRect.top + (cursorRect.y - 2) * scale)),
      width: Math.max(1, Math.ceil(glyphWidth * scale)),
      height: Math.max(1, Math.ceil((cursorRect.height + 4) * scale)),
      pageIndex,
      scale,
    };
  });
}

async function captureCompositedCrop(page, filePath, clip) {
  mkdirSync(path.dirname(filePath), { recursive: true });
  await page.evaluate(() => {
    for (const element of document.querySelectorAll('#scroll-content .caret, #scroll-content .caret-composition')) {
      element.dataset.issue2214Visibility = element.style.visibility;
      element.style.visibility = 'hidden';
    }
  });
  try {
    await page.screenshot({
      path: filePath,
      clip: { x: clip.x, y: clip.y, width: clip.width, height: clip.height },
      captureBeyondViewport: true,
    });
  } finally {
    await page.evaluate(() => {
      for (const element of document.querySelectorAll('#scroll-content .caret, #scroll-content .caret-composition')) {
        element.style.visibility = element.dataset.issue2214Visibility ?? '';
        delete element.dataset.issue2214Visibility;
      }
    });
  }
  const bytes = readFileSync(filePath);
  return { filePath, sha256: sha256(bytes), size: bytes.length, clip };
}

async function collectState(page, label, timelineStart) {
  return page.evaluate(({ checkpoint, startedAt }) => {
    const wasm = window.__wasm;
    const input = window.__inputHandler;
    const canvasView = window.__canvasView;
    const position = input.cursor.getPosition();
    const rect = input.cursor.getRect();
    const length = wasm.getCellParagraphLength(0, 0, 2, 2, 5);
    const text = wasm.getTextInCell(0, 0, 2, 2, 5, 0, length);

    const lineByIndex = new Map();
    for (let offset = 0; offset <= length; offset += 1) {
      try {
        const info = wasm.getLineInfoInCell(0, 0, 2, 2, 5, offset);
        if (info && !lineByIndex.has(info.lineIndex)) lineByIndex.set(info.lineIndex, info);
      } catch { /* end offsets differ by format; retain successfully exposed lines */ }
    }
    const lines = Array.from(lineByIndex.values()).sort((a, b) => a.lineIndex - b.lineIndex);

    const pageIndex = Number.isInteger(rect?.pageIndex) ? rect.pageIndex : 0;
    const tree = wasm.getPageLayerTreeObject(pageIndex);
    const ops = [];
    const visit = (node) => {
      if (!node) return;
      if (node.kind === 'group') for (const child of node.children ?? []) visit(child);
      else if (node.kind === 'clipRect') visit(node.child);
      else if (node.kind === 'leaf') ops.push(...(node.ops ?? []));
    };
    visit(tree.root);
    const targetOps = ops.filter((op) => {
      if (op.type !== 'textRun') return false;
      const key = op.source?.stableSourceKey ?? '';
      return key.startsWith('section:0/para:5/') && key.includes('/cell:0:2:2:5:');
    });

    let layoutRuns = [];
    let layoutError = null;
    try {
      const layout = JSON.parse(wasm.doc.getPageTextLayout(pageIndex));
      layoutRuns = (layout.runs ?? []).filter((run) => (
        run.secIdx === 0
        && run.parentParaIdx === 0
        && run.controlIdx === 2
        && run.cellIdx === 2
        && run.cellParaIdx === 5
      )).map((run) => ({
        text: run.text,
        x: run.x,
        y: run.y,
        w: run.w,
        h: run.h,
        charStart: run.charStart,
        fontFamily: run.fontFamily,
        fontSize: run.fontSize,
      }));
    } catch (error) {
      layoutError = error instanceof Error ? error.message : String(error);
    }

    const caret = document.querySelector('#scroll-content .caret');
    const caretRect = caret?.getBoundingClientRect();
    const trace = window.__issue2214Trace;
    return {
      label: checkpoint,
      atMs: performance.now() - startedAt,
      model: {
        length,
        text,
        tail: text.slice(-40),
        lineCount: lines[0]?.lineCount ?? null,
        lines,
      },
      cursor: { position, rect },
      pagination: {
        pending: input.hasDeferredPaginationPending(),
        pageCount: wasm.pageCount,
      },
      renderState: {
        pendingRaf: canvasView.textEditRefreshRafId !== null,
        pendingPages: Array.from(canvasView.pendingTextEditRefreshes.keys()),
        verificationScheduled: canvasView.textEditStaticLayerVerifyTimers.has(pageIndex),
      },
      layerTree: {
        pageIndex,
        targetText: targetOps.map((op) => op.displayText ?? op.text ?? '').join(''),
        targetOps: targetOps.map((op) => ({
          text: op.displayText ?? op.text ?? '',
          bbox: op.bbox,
          baseline: op.baseline,
          stableSourceKey: op.source?.stableSourceKey ?? null,
          utf16Range: op.source?.utf16Range ?? null,
        })),
      },
      pageTextLayout: {
        targetText: layoutRuns.map((run) => run.text ?? '').join(''),
        runs: layoutRuns,
        error: layoutError,
      },
      caret: caret ? {
        display: getComputedStyle(caret).display,
        left: caret.style.left,
        top: caret.style.top,
        height: caret.style.height,
        clientRect: caretRect ? {
          x: caretRect.x,
          y: caretRect.y,
          width: caretRect.width,
          height: caretRect.height,
        } : null,
      } : null,
      traceEventCount: trace?.events.length ?? 0,
    };
  }, { checkpoint: label, startedAt: timelineStart });
}

async function captureCheckpoint(page, directory, label, timelineStart, clip) {
  const state = await collectState(page, label, timelineStart);
  const screenshotPath = path.join(directory, `${sanitizeLabel(label)}.png`);
  state.screenshot = await captureCompositedCrop(page, screenshotPath, clip);
  return state;
}

async function discoverTransition(page, format, bytes, runNumber) {
  await restoreTrace(page);
  const load = await openDocumentThroughApp(page, format, bytes);
  await moveToTarget(page);
  const initialLineCount = await readLineCount(page);
  assert.equal(initialLineCount, 4, `${format} run ${runNumber}: expected initial four lines`);

  const handlerDurationsMs = [];
  let transitionAt = null;
  for (let inserted = 1; inserted <= MAX_INSERTS; inserted += 1) {
    const startedAt = performance.now();
    await page.keyboard.type('1');
    handlerDurationsMs.push(performance.now() - startedAt);
    const lineCount = await readLineCount(page);
    if (lineCount > initialLineCount) {
      transitionAt = inserted;
      break;
    }
  }
  assert.ok(transitionAt, `${format} run ${runNumber}: no 4→5 line transition within ${MAX_INSERTS} inputs`);
  const model = await page.evaluate(() => {
    const wasm = window.__wasm;
    const input = window.__inputHandler;
    const length = wasm.getCellParagraphLength(0, 0, 2, 2, 5);
    return {
      length,
      textTail: wasm.getTextInCell(0, 0, 2, 2, 5, Math.max(0, length - 40), Math.min(40, length)),
      cursor: input.cursor.getPosition(),
      lineCount: wasm.getLineInfoInCell(0, 0, 2, 2, 5, input.cursor.getPosition().charOffset).lineCount,
      pending: input.hasDeferredPaginationPending(),
    };
  });
  return {
    format,
    runNumber,
    inputPath: 'page.keyboard.type',
    transitionAt,
    initialLineCount,
    finalLineCount: model.lineCount,
    handler: summarizeDurations(handlerDurationsMs),
    boundaryHandlerMs: handlerDurationsMs.at(-1),
    model,
    load,
  };
}

async function prepareScenario(page, format, bytes, transitionAt) {
  await restoreTrace(page);
  const load = await openDocumentThroughApp(page, format, bytes);
  await moveToTarget(page);
  const keyboardDurationsMs = await typeKeyboardOnes(page, Math.max(0, transitionAt - 1));
  await waitTwoRafs(page);
  const clip = await resolveCompositedClip(page);
  await installTrace(page);
  return { load, clip, keyboardDurationsMs };
}

async function waitForDeferredPaginationCompletion(page, timeoutMs = 5_000) {
  const startedAt = performance.now();
  await page.waitForFunction(
    () => !window.__inputHandler.hasDeferredPaginationPending(),
    { timeout: timeoutMs, polling: 25 },
  );
  return performance.now() - startedAt;
}

async function waitForDeferredPaginationBegin(page, timeoutMs = 1_000) {
  await page.waitForFunction(
    () => (
      window.__inputHandler.hasDeferredPaginationPending()
      && (window.__issue2214Trace?.events ?? [])
        .some((event) => event.type === 'wasm.beginDeferredPagination')
    ),
    { timeout: timeoutMs, polling: 10 },
  );
}

async function runTimeline(page, format, bytes, transitionAt) {
  const directory = path.join(OUTPUT_ROOT, format, 'timeline');
  const prepared = await prepareScenario(page, format, bytes, transitionAt);
  const timelineStart = await page.evaluate(() => performance.now());
  const checkpoints = [];
  checkpoints.push(await captureCheckpoint(page, directory, 'before-boundary', timelineStart, prepared.clip));

  const boundaryInput = await dispatchInputSynchronously(page, '1');
  checkpoints.push(await captureCheckpoint(page, directory, 'sync-after-boundary', timelineStart, prepared.clip));
  await waitTwoRafs(page);
  checkpoints.push(await captureCheckpoint(page, directory, 'after-2raf', timelineStart, prepared.clip));
  await delay(page, 100);
  checkpoints.push(await captureCheckpoint(page, directory, 'after-100ms', timelineStart, prepared.clip));
  await delay(page, 750);
  checkpoints.push(await captureCheckpoint(page, directory, 'after-850ms', timelineStart, prepared.clip));
  await delay(page, 750);
  checkpoints.push(await captureCheckpoint(page, directory, 'after-1600ms', timelineStart, prepared.clip));

  const plusOne = await dispatchInputSynchronously(page, '1');
  await waitTwoRafs(page);
  checkpoints.push(await captureCheckpoint(page, directory, 'after-n-plus-1', timelineStart, prepared.clip));
  const plusTwo = await dispatchInputSynchronously(page, '1');
  await waitTwoRafs(page);
  checkpoints.push(await captureCheckpoint(page, directory, 'after-n-plus-2', timelineStart, prepared.clip));

  const trace = await collectTrace(page);
  assert.equal(trace.counts.wasmFlush, 0, `${format}: timeline must not synchronously flush at the boundary`);
  return {
    kind: 'timeline',
    format,
    transitionAt,
    load: prepared.load,
    clip: prepared.clip,
    inputDurations: {
      beforeBoundaryKeyboard: summarizeDurations(prepared.keyboardDurationsMs),
      boundarySyncMs: boundaryInput.durationMs,
      plusOneSyncMs: plusOne.durationMs,
      plusTwoSyncMs: plusTwo.durationMs,
    },
    checkpoints,
    trace,
  };
}

async function runFullLayerControl(page, format, bytes, transitionAt) {
  const directory = path.join(OUTPUT_ROOT, format, 'full-layer-control');
  const prepared = await prepareScenario(page, format, bytes, transitionAt);
  const timelineStart = await page.evaluate(() => performance.now());
  const boundaryInput = await dispatchInputSynchronously(page, '1');
  await waitTwoRafs(page);
  const before = await captureCheckpoint(page, directory, 'before-full-layer', timelineStart, prepared.clip);
  const pageIndex = before.cursor.rect?.pageIndex ?? 0;
  await page.evaluate((value) => {
    window.__eventBus.emit('document-page-invalidated', { pageIndex: value, reason: 'unknown' });
  }, pageIndex);
  await waitTwoRafs(page);
  const after = await captureCheckpoint(page, directory, 'after-full-layer', timelineStart, prepared.clip);
  const trace = await collectTrace(page);
  assert.equal(trace.counts.wasmFlush, 0, `${format}: full-layer control must not synchronously flush`);
  return {
    kind: 'full-layer-control',
    format,
    transitionAt,
    load: prepared.load,
    clip: prepared.clip,
    boundaryInputMs: boundaryInput.durationMs,
    checkpoints: [before, after],
    trace,
  };
}

async function runFlushControl(page, format, bytes, transitionAt) {
  const directory = path.join(OUTPUT_ROOT, format, 'flush-control');
  const prepared = await prepareScenario(page, format, bytes, transitionAt);
  const timelineStart = await page.evaluate(() => performance.now());
  const boundaryInput = await dispatchInputSynchronously(page, '1');
  await waitTwoRafs(page);
  const before = await captureCheckpoint(page, directory, 'before-explicit-flush', timelineStart, prepared.clip);
  const traceBefore = await collectTrace(page);
  assert.equal(traceBefore.counts.wasmFlush, 0, `${format}: boundary pagination must remain resumable`);

  const explicit = await page.evaluate(() => {
    const input = window.__inputHandler;
    const position = input.cursor.getPosition();
    const startedAt = performance.now();
    const flushed = input.flushDeferredPaginationIfNeeded('issue-2214-e2e', false);
    input.cursor.moveTo(position);
    window.__eventBus.emit('document-view-changed');
    return { flushed, durationMs: performance.now() - startedAt };
  });
  assert.equal(explicit.flushed, true, `${format}: explicit control must drain the active resumable job`);
  await waitTwoRafs(page);
  const after = await captureCheckpoint(page, directory, 'after-explicit-flush', timelineStart, prepared.clip);
  const trace = await collectTrace(page);
  assert.equal(trace.counts.wasmFlush, 1, `${format}: explicit control must not add a second pagination flush`);
  return {
    kind: 'flush-control',
    format,
    transitionAt,
    load: prepared.load,
    clip: prepared.clip,
    boundaryInputMs: boundaryInput.durationMs,
    explicit,
    checkpoints: [before, after],
    traceBefore,
    trace,
  };
}

function comparePng(actualPath, expectedPath, diffPath) {
  const actual = PNG.sync.read(readFileSync(actualPath));
  const expected = PNG.sync.read(readFileSync(expectedPath));
  if (actual.width !== expected.width || actual.height !== expected.height) {
    return {
      comparable: false,
      actual: { width: actual.width, height: actual.height },
      expected: { width: expected.width, height: expected.height },
    };
  }
  const diff = new PNG({ width: actual.width, height: actual.height });
  const changedPixelCount = pixelmatch(
    actual.data,
    expected.data,
    diff.data,
    actual.width,
    actual.height,
    { threshold: 0.1 },
  );
  let minX = actual.width;
  let minY = actual.height;
  let maxX = -1;
  let maxY = -1;
  let maxChannelDelta = 0;
  for (let y = 0; y < actual.height; y += 1) {
    for (let x = 0; x < actual.width; x += 1) {
      const offset = (y * actual.width + x) * 4;
      let changed = false;
      for (let channel = 0; channel < 4; channel += 1) {
        const delta = Math.abs(actual.data[offset + channel] - expected.data[offset + channel]);
        maxChannelDelta = Math.max(maxChannelDelta, delta);
        if (delta > 0) changed = true;
      }
      if (changed) {
        minX = Math.min(minX, x);
        minY = Math.min(minY, y);
        maxX = Math.max(maxX, x);
        maxY = Math.max(maxY, y);
      }
    }
  }
  mkdirSync(path.dirname(diffPath), { recursive: true });
  writeFileSync(diffPath, PNG.sync.write(diff));
  return {
    comparable: true,
    width: actual.width,
    height: actual.height,
    threshold: 0.1,
    changedPixelCount,
    diffRatio: changedPixelCount / (actual.width * actual.height),
    maxChannelDelta,
    rawDiffBbox: maxX >= 0 ? { minX, minY, maxX, maxY } : null,
    diffPath,
    diffSha256: sha256(readFileSync(diffPath)),
  };
}

function checkpointByLabel(result, label) {
  const checkpoint = result.checkpoints.find((value) => value.label === label);
  assert.ok(checkpoint, `checkpoint not found: ${label}`);
  return checkpoint;
}

function classifyFormat(result) {
  const timelineAtN = checkpointByLabel(result.timeline, 'after-2raf');
  const fullAfter = checkpointByLabel(result.fullLayer, 'after-full-layer');
  const flushAfter = checkpointByLabel(result.flush, 'after-explicit-flush');
  const comparisons = {
    timelineVsFlush: comparePng(
      timelineAtN.screenshot.filePath,
      flushAfter.screenshot.filePath,
      path.join(OUTPUT_ROOT, result.format, 'diff', 'timeline-vs-flush.png'),
    ),
    fullLayerVsFlush: comparePng(
      fullAfter.screenshot.filePath,
      flushAfter.screenshot.filePath,
      path.join(OUTPUT_ROOT, result.format, 'diff', 'full-layer-vs-flush.png'),
    ),
  };

  const modelLatest = timelineAtN.model.text.endsWith('1'.repeat(result.transitionAt));
  const linesLatest = timelineAtN.model.lineCount === 5;
  const treeMatchesFlush = timelineAtN.layerTree.targetText === flushAfter.layerTree.targetText;
  const layoutMatchesFlush = timelineAtN.pageTextLayout.targetText === flushAfter.pageTextLayout.targetText;
  const pixelStale = comparisons.timelineVsFlush.comparable
    && comparisons.timelineVsFlush.changedPixelCount > 0;
  const fullLayerRecovers = comparisons.fullLayerVsFlush.comparable
    && comparisons.fullLayerVsFlush.changedPixelCount === 0;

  let cause = 'existing-green';
  if (!modelLatest || !linesLatest) cause = 'document-core-mutation-or-reflow';
  else if (pixelStale && fullLayerRecovers) cause = 'static-reuse-or-page-local-render-context';
  else if (pixelStale && !layoutMatchesFlush && !fullLayerRecovers) cause = 'stale-layout-input';
  else if (pixelStale && !treeMatchesFlush && !fullLayerRecovers) cause = 'stale-cached-page-tree';
  else if (pixelStale && !fullLayerRecovers) cause = 'explicit-pagination-only-or-multiple-boundaries';

  return {
    verdict: pixelStale ? 'RED' : 'GREEN',
    cause,
    modelLatest,
    linesLatest,
    treeMatchesFlush,
    layoutMatchesFlush,
    fullLayerRecovers,
    comparisons,
  };
}

async function runFormat(page, format, bytes, discoveryRuns) {
  console.log(`\n[${format.toUpperCase()}] keyboard transition discovery (${discoveryRuns} runs)`);
  const discoveries = [];
  for (let run = 1; run <= discoveryRuns; run += 1) {
    const discovery = await discoverTransition(page, format, bytes, run);
    discoveries.push(discovery);
    console.log(`  run ${run}: N=${discovery.transitionAt}, boundary=${discovery.boundaryHandlerMs.toFixed(2)}ms`);
  }
  const transitionValues = new Set(discoveries.map((value) => value.transitionAt));
  assert.equal(transitionValues.size, 1, `${format}: keyboard transition N is not deterministic`);
  const transitionAt = discoveries[0].transitionAt;

  console.log(`  timeline at N=${transitionAt}`);
  const timeline = await runTimeline(page, format, bytes, transitionAt);
  console.log('  independent page-only full-layer control');
  const fullLayer = await runFullLayerControl(page, format, bytes, transitionAt);
  console.log('  independent explicit-pagination control');
  const flush = await runFlushControl(page, format, bytes, transitionAt);

  const result = {
    format,
    transitionAt,
    discoveries,
    timeline,
    fullLayer,
    flush,
  };
  result.classification = classifyFormat(result);
  writeJson(path.join(OUTPUT_ROOT, `${format}-diagnostic.json`), result);
  console.log(`  verdict=${result.classification.verdict}, cause=${result.classification.cause}`);
  return result;
}

function assertApprox(actual, expected, label, tolerance = 0.2) {
  assert.equal(typeof actual, 'number', `${label}: expected a number`);
  assert.ok(
    Math.abs(actual - expected) <= tolerance,
    `${label}: expected ${expected} +/- ${tolerance}, got ${actual}`,
  );
}

async function readFocusedSnapshot(page) {
  return page.evaluate((target) => {
    const wasm = window.__wasm;
    const input = window.__inputHandler;
    const position = input.cursor.getPosition();
    const rect = input.cursor.getRect();
    const length = wasm.getCellParagraphLength(
      target.sectionIndex,
      target.parentParaIndex,
      target.controlIndex,
      target.cellIndex,
      target.cellParaIndex,
    );
    const text = wasm.getTextInCell(
      target.sectionIndex,
      target.parentParaIndex,
      target.controlIndex,
      target.cellIndex,
      target.cellParaIndex,
      0,
      length,
    );
    const lineInfo = wasm.getLineInfoInCell(
      target.sectionIndex,
      target.parentParaIndex,
      target.controlIndex,
      target.cellIndex,
      target.cellParaIndex,
      position.charOffset,
    );
    return {
      model: { length, text, lineCount: lineInfo.lineCount },
      cursor: { position, rect },
      pagination: {
        pending: input.hasDeferredPaginationPending(),
        pageCount: wasm.pageCount,
      },
    };
  }, TARGET);
}

function assertFocusedSnapshot(format, runNumber, inserted, snapshot, expectedText) {
  const prefix = `${format} run ${runNumber} input ${inserted}`;
  const expectedLength = TARGET.charOffset + inserted;
  assert.equal(snapshot.model.length, expectedLength, `${prefix}: model length`);
  assert.equal(snapshot.model.text, expectedText, `${prefix}: model text`);
  assert.equal(snapshot.model.lineCount, inserted < 56 ? 4 : 5, `${prefix}: line count`);
  assert.equal(snapshot.pagination.pageCount, 115, `${prefix}: page count`);

  const position = snapshot.cursor.position;
  assert.equal(position.sectionIndex, TARGET.sectionIndex, `${prefix}: cursor section`);
  assert.equal(position.parentParaIndex, TARGET.parentParaIndex, `${prefix}: cursor parent paragraph`);
  assert.equal(position.controlIndex, TARGET.controlIndex, `${prefix}: cursor control`);
  assert.equal(position.cellIndex, TARGET.cellIndex, `${prefix}: cursor cell`);
  assert.equal(position.cellParaIndex, TARGET.cellParaIndex, `${prefix}: cursor cell paragraph`);
  assert.equal(position.charOffset, expectedLength, `${prefix}: cursor offset`);
  assert.deepEqual(position.cellPath, TARGET.cellPath, `${prefix}: cursor cell path`);

  const rect = snapshot.cursor.rect;
  assert.equal(rect?.pageIndex, 0, `${prefix}: cursor page`);
  assert.equal(rect?.cellOverflowed, false, `${prefix}: cursor must not use overflow fallback`);
  assertApprox(rect?.cellBounds?.h, 945.9, `${prefix}: cell bounds`);
  assert.equal(snapshot.pagination.pending, true, `${prefix}: deferred pagination pending state`);
}

function targetRunStart(op, label) {
  const match = op.stableSourceKey?.match(/\/char:(\d+)(?:\/|$)/);
  assert.ok(match, `${label}: target TextRun stableSourceKey lacks char offset`);
  return Number(match[1]);
}

function assertExactFocusedState(
  format,
  runNumber,
  state,
  expectedText,
  expectedLineCount,
  expectedBoundsHeight,
  expectedPending,
  expectedCaretVisible = true,
  expectedPageCount = 115,
) {
  const prefix = `${format} run ${runNumber} ${state.label}`;
  const expectedLength = expectedText.length;
  assert.equal(state.model.length, expectedLength, `${prefix}: model length`);
  assert.equal(state.model.text, expectedText, `${prefix}: model text`);
  assert.equal(state.model.lineCount, expectedLineCount, `${prefix}: line count`);
  assert.equal(state.pagination.pageCount, expectedPageCount, `${prefix}: page count`);
  if (expectedPending !== null) {
    assert.equal(state.pagination.pending, expectedPending, `${prefix}: pending state`);
  }
  assert.equal(state.layerTree.pageIndex, 0, `${prefix}: tree page`);
  assert.equal(state.layerTree.targetText, expectedText, `${prefix}: layer tree text`);
  assert.equal(state.pageTextLayout.error, null, `${prefix}: page text layout error`);
  assert.equal(state.pageTextLayout.targetText, expectedText, `${prefix}: page text layout text`);

  const ops = state.layerTree.targetOps;
  assert.ok(ops.length > 0, `${prefix}: target TextRuns`);
  let contiguousEnd = 0;
  for (const [index, op] of ops.entries()) {
    const start = targetRunStart(op, `${prefix} op ${index}`);
    assert.equal(start, contiguousEnd, `${prefix}: TextRun ${index} must be contiguous`);
    const textLength = String(op.text ?? '').length;
    assert.ok(textLength > 0, `${prefix}: TextRun ${index} must advance`);
    contiguousEnd = start + textLength;
  }
  assert.equal(contiguousEnd, expectedLength, `${prefix}: layer tree UTF-16 end`);

  const position = state.cursor.position;
  assert.equal(position.charOffset, expectedLength, `${prefix}: cursor offset`);
  assert.equal(position.sectionIndex, TARGET.sectionIndex, `${prefix}: cursor section`);
  assert.equal(position.parentParaIndex, TARGET.parentParaIndex, `${prefix}: cursor parent paragraph`);
  assert.equal(position.controlIndex, TARGET.controlIndex, `${prefix}: cursor control`);
  assert.equal(position.cellIndex, TARGET.cellIndex, `${prefix}: cursor cell`);
  assert.equal(position.cellParaIndex, TARGET.cellParaIndex, `${prefix}: cursor cell paragraph`);
  assert.deepEqual(position.cellPath, TARGET.cellPath, `${prefix}: cursor cell path`);

  const rect = state.cursor.rect;
  const lastOp = ops.at(-1);
  assert.equal(rect?.pageIndex, 0, `${prefix}: cursor page`);
  assert.equal(rect?.cellOverflowed, false, `${prefix}: cursor overflow fallback`);
  assertApprox(rect?.cellBounds?.h, expectedBoundsHeight, `${prefix}: cell bounds`);
  assertApprox(rect?.x, lastOp.bbox.x + lastOp.bbox.width, `${prefix}: cursor x at tree end`);
  assertApprox(rect?.y, lastOp.bbox.y, `${prefix}: cursor y at tree end`);
  assertApprox(rect?.height, lastOp.bbox.height, `${prefix}: cursor height`);

  if (expectedCaretVisible) {
    assert.ok(state.caret, `${prefix}: DOM caret`);
    assert.equal(state.caret.display, 'block', `${prefix}: DOM caret display`);
    assert.ok(state.caret.clientRect?.width > 0, `${prefix}: DOM caret width`);
    assertApprox(state.caret.clientRect?.height, rect.height, `${prefix}: DOM caret height`);
  }
}

function assertContinuousFlowGeometry(format, label, state, digitTokenStart) {
  const prefix = `${format} ${label}`;
  const bounds = state.cursor.rect?.cellBounds;
  assert.ok(bounds, `${prefix}: cell bounds`);
  const left = bounds.x;
  const right = bounds.x + bounds.w;
  const digitOps = [];
  const suffixBands = [];
  for (const [index, op] of state.layerTree.targetOps.entries()) {
    const start = targetRunStart(op, `${prefix} op ${index}`);
    const textLength = String(op.text ?? '').length;
    // Existing justified source lines in this fixture carry their original ink
    // envelope. Validate every run that contains or follows the edited suffix.
    if (start + textLength <= TARGET.charOffset) continue;
    assert.ok(
      op.bbox.x >= left - 0.2,
      `${prefix}: TextRun ${index} left=${op.bbox.x}, cellLeft=${left}`,
    );
    assert.ok(
      op.bbox.x + op.bbox.width <= right + 0.2,
      `${prefix}: TextRun ${index} right=${op.bbox.x + op.bbox.width}, cellRight=${right}, `
        + `key=${op.stableSourceKey}, text=${JSON.stringify(op.text)}`,
    );
    if (start + textLength > digitTokenStart) {
      suffixBands.push({ top: op.bbox.y, bottom: op.bbox.y + op.bbox.height });
    }
    if (start >= digitTokenStart && /^1+$/.test(op.text)) digitOps.push(op);
  }
  assert.ok(state.model.lines.length > 0, `${prefix}: line ranges`);
  assert.equal(state.model.lines[0].charStart, 0, `${prefix}: first line start`);
  for (let index = 1; index < state.model.lines.length; index += 1) {
    assert.equal(
      state.model.lines[index - 1].charEnd,
      state.model.lines[index].charStart,
      `${prefix}: line ${index - 1}→${index} UTF-16 continuity`,
    );
  }
  assert.equal(state.model.lines.at(-1).charEnd, state.model.length, `${prefix}: final line end`);
  assert.ok(digitOps.length >= 2, `${prefix}: numeric suffix line runs`);
  const naturalAdvance = digitOps.at(-1).bbox.width / digitOps.at(-1).text.length;
  assert.ok(naturalAdvance <= state.cursor.rect.height, `${prefix}: final digit advance`);
  for (const [index, op] of digitOps.entries()) {
    const advance = op.bbox.width / op.text.length;
    assert.ok(advance <= naturalAdvance * 1.5 + 0.2, `${prefix}: digit run ${index} stretch ${advance}`);
  }
  const bands = [];
  for (const band of suffixBands.sort((a, b) => a.top - b.top)) {
    const previous = bands.at(-1);
    if (previous && Math.abs(band.top - previous.top) <= 0.2) {
      previous.bottom = Math.max(previous.bottom, band.bottom);
    } else {
      bands.push({ ...band });
    }
  }
  for (let index = 1; index < bands.length; index += 1) {
    assert.ok(bands[index].top >= bands[index - 1].bottom - 0.2, `${prefix}: suffix line overlap`);
  }
}

function assertFocusedTrace(format, runNumber, trace) {
  const prefix = `${format} run ${runNumber}`;
  const inserts = trace.events.filter((event) => event.type === 'wasm.insertTextInCellDeferredPagination');
  const effects = trace.events.filter((event) => event.type === 'InputHandler.prepareTextMutationBeforeCursor');
  const begins = trace.events.filter((event) => event.type === 'wasm.beginDeferredPagination');
  const steps = trace.events.filter((event) => event.type === 'wasm.stepDeferredPagination');
  const flushes = trace.events.filter((event) => event.type === 'wasm.flushDeferredPagination');
  const inputFlushes = trace.events.filter((event) => event.type === 'input.flushDeferredPaginationIfNeeded');
  const cursorQueries = trace.events.filter((event) => event.type === 'wasm.getCursorRectByPathNear');
  const operations = trace.events.filter((event) => event.type === 'InputHandler.executeOperation');

  assert.equal(inserts.length, 62, `${prefix}: deferred insert count`);
  assert.equal(effects.length, 62, `${prefix}: consumed mutation effect count`);
  assert.equal(begins.length, 1, `${prefix}: resumable begin count`);
  assert.equal(steps.length, 115, `${prefix}: one-fragment step count`);
  assert.equal(
    steps.reduce((sum, event) => sum + event.fragmentsProcessed, 0),
    115,
    `${prefix}: processed fragment count`,
  );
  assert.equal(steps.at(-1)?.status, 'complete', `${prefix}: final resumable status`);
  assert.equal(flushes.length, 0, `${prefix}: synchronous WASM flush count`);
  assert.equal(inputFlushes.length, 0, `${prefix}: synchronous input flush count`);
  assert.equal(operations.length, 62, `${prefix}: operation count`);

  for (let index = 0; index < inserts.length; index += 1) {
    const inserted = index + 1;
    const expectedFlowChange = inserted === 56;
    assert.equal(inserts[index].charOffset, TARGET.charOffset + index, `${prefix}: input ${inserted} source offset`);
    assert.equal(inserts[index].resultCharOffset, TARGET.charOffset + inserted, `${prefix}: input ${inserted} result offset`);
    assert.equal(inserts[index].paginationDeferred, true, `${prefix}: input ${inserted} deferred result`);
    assert.equal(inserts[index].cellFlowChanged, expectedFlowChange, `${prefix}: input ${inserted} flow result`);
    assert.equal(effects[index].deferredPagination, true, `${prefix}: input ${inserted} consumed deferred effect`);
    assert.equal(effects[index].cellFlowChanged, expectedFlowChange, `${prefix}: input ${inserted} consumed flow effect`);
    assert.equal(effects[index].paginationCompleted, false, `${prefix}: input ${inserted} deferred completion state`);
  }

  const boundaryInsert = inserts[55];
  const boundaryBegin = begins[0];
  const firstCursorAfterBoundary = cursorQueries.find((event) => event.sequence > boundaryInsert.sequence);
  assert.ok(firstCursorAfterBoundary, `${prefix}: cursor query after boundary`);
  assert.ok(
    boundaryInsert.sequence < boundaryBegin.sequence,
    `${prefix}: mutation result must precede resumable begin`,
  );
  assert.ok(
    firstCursorAfterBoundary.sequence < boundaryBegin.sequence,
    `${prefix}: cursor query and input paint must precede async resumable begin`,
  );

  const operationDurations = operations.map((event) => event.durationMs);
  const stableOperationDurations = operationDurations.filter((_, index) => index !== 55);
  const stableKeyboardDurations = trace.keyboardDurationsMs.filter((_, index) => index !== 55);
  const cursorDurations = cursorQueries.map((event) => event.durationMs);
  return {
    counts: trace.counts,
    ordering: {
      boundaryMutationSequence: boundaryInsert.sequence,
      boundaryBeginSequence: boundaryBegin.sequence,
      boundaryCursorSequence: firstCursorAfterBoundary.sequence,
    },
    timing: {
      keyboardStable: summarizeDurations(stableKeyboardDurations),
      keyboardBoundaryMs: trace.keyboardDurationsMs[55],
      operationStable: summarizeDurations(stableOperationDurations),
      operationBoundaryMs: operationDurations[55],
      boundaryBeginMs: boundaryBegin.durationMs,
      resumableSteps: summarizeDurations(steps.map((event) => event.durationMs)),
      cursorQueries: summarizeDurations(cursorDurations),
      boundaryCursorMs: firstCursorAfterBoundary.durationMs,
    },
  };
}

async function runFocusedFormat(page, format, bytes, runNumber) {
  await restoreTrace(page);
  const load = await openDocumentThroughApp(page, format, bytes);
  await moveToTarget(page);
  const timelineStart = await page.evaluate(() => performance.now());
  const initial = await collectState(page, 'initial-warm', timelineStart);
  const initialText = initial.model.text;
  assert.equal(initialText.length, TARGET.charOffset, `${format} run ${runNumber}: initial text length`);
  assertExactFocusedState(format, runNumber, initial, initialText, 4, 945.9, false);
  const clip = await resolveCompositedClip(page);
  const visualDirectory = path.join(OUTPUT_ROOT, 'focused', format, `run-${runNumber}`);
  const visual = { beforeBoundary: null, boundary: [], comparisons: [] };

  await installTrace(page);
  const keyboardDurationsMs = [];
  const checkpoints = { initial };
  for (let inserted = 1; inserted <= 62; inserted += 1) {
    const startedAt = performance.now();
    await page.keyboard.type('1');
    keyboardDurationsMs.push(performance.now() - startedAt);

    const expectedText = `${initialText}${'1'.repeat(inserted)}`;
    const snapshot = await readFocusedSnapshot(page);
    assertFocusedSnapshot(format, runNumber, inserted, snapshot, expectedText);

    if (inserted === 55) {
      const traceAt55 = await collectTrace(page);
      assert.equal(traceAt55.counts.wasmFlush, 0, `${format} run ${runNumber}: inputs 1-55 flush count`);
      await waitTwoRafs(page);
      checkpoints.at55 = await collectState(page, 'after-55-2raf', timelineStart);
      assertExactFocusedState(format, runNumber, checkpoints.at55, expectedText, 4, 945.9, true);
      visual.beforeBoundary = await captureCompositedCrop(
        page,
        path.join(visualDirectory, 'after-55.png'),
        clip,
      );
    }

    if (inserted === 56) {
      const boundaryStates = [];
      boundaryStates.push(await collectState(page, 'after-56-sync', timelineStart));
      await waitTwoRafs(page);
      boundaryStates.push(await collectState(page, 'after-56-2raf', timelineStart));
      visual.boundary.push(await captureCompositedCrop(
        page,
        path.join(visualDirectory, 'after-56-2raf.png'),
        clip,
      ));
      await delay(page, 100);
      boundaryStates.push(await collectState(page, 'after-56-100ms', timelineStart));
      visual.boundary.push(await captureCompositedCrop(
        page,
        path.join(visualDirectory, 'after-56-100ms.png'),
        clip,
      ));
      await delay(page, 750);
      boundaryStates.push(await collectState(page, 'after-56-850ms', timelineStart));
      visual.boundary.push(await captureCompositedCrop(
        page,
        path.join(visualDirectory, 'after-56-850ms.png'),
        clip,
      ));
      await delay(page, 750);
      boundaryStates.push(await collectState(page, 'after-56-1600ms', timelineStart));
      visual.boundary.push(await captureCompositedCrop(
        page,
        path.join(visualDirectory, 'after-56-1600ms.png'),
        clip,
      ));
      const completionWaitMs = await waitForDeferredPaginationCompletion(page);
      boundaryStates.push(await collectState(page, 'after-56-complete', timelineStart));
      visual.boundary.push(await captureCompositedCrop(
        page,
        path.join(visualDirectory, 'after-56-complete.png'),
        clip,
      ));
      const pendingExpectations = [true, true, null, null, null, false];
      for (const [index, state] of boundaryStates.entries()) {
        assertExactFocusedState(
          format,
          runNumber,
          state,
          expectedText,
          5,
          945.9,
          pendingExpectations[index],
        );
        const traceAtCheckpoint = await collectTrace(page);
        assert.equal(
          traceAtCheckpoint.counts.wasmFlush,
          0,
          `${format} run ${runNumber} ${state.label}: cumulative flush count`,
        );
      }
      const transitionComparison = comparePng(
        visual.boundary[0].filePath,
        visual.beforeBoundary.filePath,
        path.join(visualDirectory, 'diff-55-vs-56.png'),
      );
      assert.equal(transitionComparison.comparable, true, `${format} run ${runNumber}: transition crop comparable`);
      assert.ok(transitionComparison.changedPixelCount > 0, `${format} run ${runNumber}: boundary crop must change`);
      visual.comparisons.push({ label: '55-vs-56', ...transitionComparison });
      for (let index = 1; index < visual.boundary.length; index += 1) {
        const comparison = comparePng(
          visual.boundary[index].filePath,
          visual.boundary[0].filePath,
          path.join(visualDirectory, `diff-56-${index}.png`),
        );
        assert.equal(comparison.comparable, true, `${format} run ${runNumber}: stable crop ${index} comparable`);
        assert.equal(comparison.changedPixelCount, 0, `${format} run ${runNumber}: boundary crop ${index} stable`);
        assert.equal(
          visual.boundary[index].sha256,
          visual.boundary[0].sha256,
          `${format} run ${runNumber}: boundary crop ${index} exact hash`,
        );
        visual.comparisons.push({ label: `56-stable-${index}`, ...comparison });
      }
      checkpoints.at56 = { states: boundaryStates, completionWaitMs };
    }
  }

  await waitTwoRafs(page);
  const finalText = `${initialText}${'1'.repeat(62)}`;
  checkpoints.at62 = await collectState(page, 'after-62-2raf', timelineStart);
  assertExactFocusedState(format, runNumber, checkpoints.at62, finalText, 5, 945.9, true);

  const trace = await collectTrace(page);
  trace.keyboardDurationsMs = keyboardDurationsMs;
  assert.equal(trace.counts.wasmFlush, 0, `${format} run ${runNumber}: inputs 57-62 add no flush`);
  const traceSummary = assertFocusedTrace(format, runNumber, trace);
  console.log(
    `  run ${runNumber}: GREEN, flush=0, steps=${traceSummary.counts.wasmStep}, `
      + `boundary=${traceSummary.timing.operationBoundaryMs.toFixed(2)}ms, `
      + `begin=${traceSummary.timing.boundaryBeginMs.toFixed(2)}ms, `
      + `stableP95=${traceSummary.timing.operationStable.p95Ms.toFixed(2)}ms`,
  );

  return {
    format,
    runNumber,
    load,
    transitionAt: 56,
    pageCount: checkpoints.at62.pagination.pageCount,
    finalLength: checkpoints.at62.model.length,
    trace: traceSummary,
    visual,
  };
}

async function runContinuousImeDigitSmoke(page, format, bytes) {
  await restoreTrace(page);
  await openDocumentThroughApp(page, format, bytes);
  await moveToTarget(page);
  const initial = await readFocusedSnapshot(page);
  const initialText = initial.model.text;
  const clip = await resolveCompositedClip(page);
  const directory = path.join(OUTPUT_ROOT, 'continuous-ime-digit', format);
  const timelineStart = await page.evaluate(() => performance.now());
  await installTrace(page);

  const stableKeyboardDurationsMs = await typeKeyboardOnes(page, 55);
  await waitTwoRafs(page);
  const beforeCompositionText = `${initialText}${'1'.repeat(55)}`;
  const beforeComposition = await readFocusedSnapshot(page);
  assert.equal(beforeComposition.model.text, beforeCompositionText, `${format} continuous IME precondition text`);
  assert.equal(beforeComposition.model.lineCount, 4, `${format} continuous IME precondition lines`);
  assert.equal(beforeComposition.pagination.pending, true, `${format} continuous IME precondition pending`);

  await page.evaluate(() => {
    window.__inputHandler.textarea.dispatchEvent(new CompositionEvent('compositionstart', {
      bubbles: true,
      data: '',
    }));
  });
  const compositionStates = [];
  const compositionCaptures = {};
  let glyphClip = null;
  for (const value of ['ㅎ', '하', '한']) {
    await page.evaluate((text) => {
      const textarea = window.__inputHandler.textarea;
      textarea.value = text;
      textarea.dispatchEvent(new InputEvent('input', {
        bubbles: true,
        data: text,
        inputType: 'insertCompositionText',
        isComposing: true,
      }));
    }, value);
    await waitTwoRafs(page);
    const expectedText = `${initialText}${'1'.repeat(55)}${value}`;
    const state = await collectState(page, `continuous-ime-${value}-2raf`, timelineStart);
    assert.equal(state.model.lineCount, 5, `${format} continuous IME ${value}: flow line count`);
    assertExactFocusedState(
      format,
      'continuous-ime-digit',
      state,
      expectedText,
      5,
      945.9,
      true,
      false,
    );
    compositionStates.push(state);

    if (value === '하') {
      glyphClip = await resolveCaretGlyphClip(page);
      compositionCaptures.ha = await captureCompositedCrop(
        page,
        path.join(directory, 'ime-ha-2raf.png'),
        glyphClip,
      );
    } else if (value === '한') {
      assert.ok(glyphClip, `${format} continuous IME: glyph clip`);
      compositionCaptures.han = await captureCompositedCrop(
        page,
        path.join(directory, 'ime-han-2raf.png'),
        glyphClip,
      );
    }
  }
  const compositionInkComparison = comparePng(
    compositionCaptures.han.filePath,
    compositionCaptures.ha.filePath,
    path.join(directory, 'ime-ha-vs-han-diff.png'),
  );
  assert.equal(compositionInkComparison.comparable, true, `${format} continuous IME: glyph crop comparable`);
  assert.ok(
    compositionInkComparison.changedPixelCount > 0,
    `${format} continuous IME: 한 must replace 하 in the composited canvas within 2-rAF`,
  );
  assert.notEqual(
    compositionCaptures.han.sha256,
    compositionCaptures.ha.sha256,
    `${format} continuous IME: glyph crop hash`,
  );
  await page.evaluate(() => {
    window.__inputHandler.textarea.dispatchEvent(new CompositionEvent('compositionend', {
      bubbles: true,
      data: '한',
    }));
  });

  // Put the following digit token behind an explicit break opportunity. This is the
  // browser form of #3822: the old composer moved an overlong token after the prior
  // break, then skipped character-level breaking for that token.
  await waitForDeferredPaginationBegin(page);
  await page.keyboard.type(' ');
  const separatorText = `${initialText}${'1'.repeat(55)}한 `;
  const separatorState = await readFocusedSnapshot(page);
  assert.equal(separatorState.model.text, separatorText, `${format} continuous IME separator text`);
  assert.equal(separatorState.pagination.pending, true, `${format} continuous IME separator pending`);

  // Cross two digit line boundaries while that pagination job is active. No
  // completion wait is allowed before the second wrap is observed.
  let digitCount = 0;
  const digitWraps = [];
  let tailInputsRemaining = null;
  const initialImeLineCount = separatorState.model.lineCount;
  let previousLineCount = initialImeLineCount;
  const durationsMs = [];
  while (digitCount < CONTINUOUS_WRAP_MAX_INSERTS) {
    digitCount += 1;
    const startedAt = performance.now();
    await page.keyboard.type('1');
    durationsMs.push(performance.now() - startedAt);
    const expectedText = `${separatorText}${'1'.repeat(digitCount)}`;
    const snapshot = await readFocusedSnapshot(page);
    const prefix = `${format} continuous IME digit ${digitCount}`;
    assert.equal(snapshot.model.text, expectedText, `${prefix}: model text`);
    assert.equal(snapshot.model.length, expectedText.length, `${prefix}: model length`);
    assert.equal(snapshot.cursor.position.charOffset, expectedText.length, `${prefix}: cursor offset`);
    assert.equal(snapshot.pagination.pageCount, 115, `${prefix}: page count`);
    assert.equal(snapshot.pagination.pending, true, `${prefix}: pending`);
    assert.equal(snapshot.cursor.rect?.cellOverflowed, false, `${prefix}: cursor overflow`);

    if (snapshot.model.lineCount > previousLineCount) {
      digitWraps.push({ digitCount, from: previousLineCount, to: snapshot.model.lineCount });
      previousLineCount = snapshot.model.lineCount;
    }
    if (snapshot.model.lineCount >= initialImeLineCount + 2 && tailInputsRemaining === null) {
      assert.equal(snapshot.pagination.pending, true, `${format} continuous IME: second wrap pending`);
      tailInputsRemaining = CONTINUOUS_WRAP_TAIL_INPUTS;
    } else if (tailInputsRemaining !== null) {
      tailInputsRemaining -= 1;
      if (tailInputsRemaining === 0) break;
    }
    await delay(page, CONTINUOUS_INPUT_MIN_GAP_MS);
  }
  assert.deepEqual(
    digitWraps.map((wrap) => wrap.digitCount),
    [11, 69],
    `${format} continuous IME: deterministic digit line transitions`,
  );
  assert.equal(tailInputsRemaining, 0, `${format} continuous IME: post-wrap tail inputs`);

  await waitTwoRafs(page);
  const expectedText = `${separatorText}${'1'.repeat(digitCount)}`;
  const expectedLineCount = initialImeLineCount + 2;
  const digitTokenStart = TARGET.charOffset + 57;
  const pendingState = await collectState(page, 'continuous-ime-digit-second-tail-2raf', timelineStart);
  assertExactFocusedState(
    format,
    'continuous-ime-digit',
    pendingState,
    expectedText,
    expectedLineCount,
    945.9,
    true,
  );
  assertContinuousFlowGeometry(format, 'continuous IME digit pending', pendingState, digitTokenStart);
  const pendingCapture = await captureCompositedCrop(
    page,
    path.join(directory, 'ime-digit-pending.png'),
    clip,
  );

  await waitForDeferredPaginationCompletion(page, 15_000);
  const completedState = await collectState(page, 'continuous-ime-digit-complete', timelineStart);
  assertExactFocusedState(
    format,
    'continuous-ime-digit',
    completedState,
    expectedText,
    expectedLineCount,
    945.9,
    false,
    true,
    116,
  );
  assertContinuousFlowGeometry(format, 'continuous IME digit complete', completedState, digitTokenStart);
  const completedCapture = await captureCompositedCrop(
    page,
    path.join(directory, 'ime-digit-complete.png'),
    clip,
  );
  const comparison = comparePng(
    completedCapture.filePath,
    pendingCapture.filePath,
    path.join(directory, 'ime-digit-pending-vs-complete-diff.png'),
  );
  assert.equal(comparison.comparable, true, `${format} continuous IME: comparable crop`);
  assert.equal(comparison.changedPixelCount, 0, `${format} continuous IME: pending ink must be final ink`);
  assert.equal(completedCapture.sha256, pendingCapture.sha256, `${format} continuous IME: exact crop hash`);

  const trace = await collectTrace(page);
  const begins = trace.events.filter((event) => event.type === 'wasm.beginDeferredPagination');
  const steps = trace.events.filter((event) => event.type === 'wasm.stepDeferredPagination');
  const latestBegin = begins.at(-1);
  const finalStep = steps.at(-1);
  assert.ok(latestBegin, `${format} continuous IME: latest deferred begin`);
  assert.ok(finalStep, `${format} continuous IME: final deferred step`);
  assert.equal(finalStep.status, 'complete', `${format} continuous IME: final deferred status`);
  assert.equal(finalStep.pageCount, 116, `${format} continuous IME: final deferred page count`);
  assert.equal(
    finalStep.revision,
    latestBegin.revision,
    `${format} continuous IME: latest begin/final step revision`,
  );
  assert.ok(
    latestBegin.sequence < finalStep.sequence,
    `${format} continuous IME: latest begin must precede final step`,
  );
  assert.equal(trace.counts.deferredReplace, 2, `${format} continuous IME: replacement count`);
  assert.equal(trace.counts.wasmFlush, 0, `${format} continuous IME: WASM flush`);
  assert.equal(trace.counts.inputFlush, 0, `${format} continuous IME: input flush`);
  const operationDurationsMs = traceDurations(trace, 'InputHandler.executeOperation');
  assert.equal(
    operationDurationsMs.length,
    57 + digitCount,
    `${format} continuous IME: operation timing count`,
  );
  const timing = {
    keyboardBeforeFlow: summarizeDurations(stableKeyboardDurationsMs),
    keyboardPendingFlow: summarizeDurations(durationsMs),
    operationBeforeFlow: summarizeDurations(operationDurationsMs.slice(0, 55)),
    operationPendingFlow: summarizeDurations(operationDurationsMs.slice(55)),
    cursorQuery: summarizeDurations(traceDurations(trace, 'wasm.getCursorRectByPathNear')),
    filteredRender: summarizeDurations(traceDurations(trace, 'wasm.renderPageToCanvasFiltered')),
    pageRender: summarizeDurations(traceDurations(trace, 'PageRenderer.renderPage')),
  };
  await restoreTrace(page);
  console.log(
    `  continuous IME→digit: correctness GREEN, wraps=${digitWraps.map((wrap) => wrap.digitCount).join('/')}, `
      + `digits=${digitCount}, `
      + `pendingOpP95=${timing.operationPendingFlow.p95Ms.toFixed(1)}ms`,
  );
  return {
    format,
    correctness: 'passed',
    latency: 'measured-not-gated',
    compositionStates: compositionStates.map((state) => ({
      label: state.label,
      lineCount: state.model.lineCount,
      pending: state.pagination.pending,
    })),
    digitWraps,
    digitCount,
    durations: summarizeDurations(durationsMs),
    timing,
    traceCounts: trace.counts,
    paginationTrace: {
      beginCount: begins.length,
      latestBeginRevision: latestBegin.revision,
      finalStepRevision: finalStep.revision,
      finalStepStatus: finalStep.status,
      finalStepPageCount: finalStep.pageCount,
    },
    compositionCaptures,
    compositionInkComparison,
    pendingCapture,
    completedCapture,
    comparison,
  };
}

function assertRawBoundaryTrace(format, kind, trace) {
  const prefix = `${format} ${kind} raw boundary`;
  const inserts = trace.events.filter((event) => event.type === 'wasm.insertTextInCellDeferredPagination');
  const effects = trace.events.filter((event) => event.type === 'InputHandler.prepareTextMutationBeforeCursor');
  const begins = trace.events.filter((event) => event.type === 'wasm.beginDeferredPagination');
  const steps = trace.events.filter((event) => event.type === 'wasm.stepDeferredPagination');
  const flushes = trace.events.filter((event) => event.type === 'wasm.flushDeferredPagination');
  const cursorQueries = trace.events.filter((event) => event.type === 'wasm.getCursorRectByPathNear');

  assert.equal(inserts.length, 1, `${prefix}: deferred insert count`);
  assert.equal(inserts[0].charOffset, TARGET.charOffset + 55, `${prefix}: source offset`);
  assert.equal(inserts[0].resultCharOffset, TARGET.charOffset + 56, `${prefix}: result offset`);
  assert.equal(inserts[0].paginationDeferred, true, `${prefix}: deferred result`);
  assert.equal(inserts[0].cellFlowChanged, true, `${prefix}: flow boundary result`);
  assert.equal(effects.length, 1, `${prefix}: consumed effect count`);
  assert.equal(effects[0].deferredPagination, true, `${prefix}: consumed deferred effect`);
  assert.equal(effects[0].cellFlowChanged, true, `${prefix}: consumed flow effect`);
  assert.equal(effects[0].paginationCompleted, false, `${prefix}: deferred completion state`);
  assert.equal(begins.length, 1, `${prefix}: resumable begin count`);
  assert.equal(steps.length, 115, `${prefix}: one-fragment step count`);
  assert.equal(steps.at(-1)?.status, 'complete', `${prefix}: final resumable status`);
  assert.equal(flushes.length, 0, `${prefix}: synchronous flush count`);

  const firstCursorQuery = cursorQueries.find((event) => event.sequence > inserts[0].sequence);
  assert.ok(firstCursorQuery, `${prefix}: cursor query after mutation`);
  assert.ok(inserts[0].sequence < begins[0].sequence, `${prefix}: mutation must precede resumable begin`);
  assert.ok(
    firstCursorQuery.sequence < begins[0].sequence,
    `${prefix}: cursor query and input paint must precede async resumable begin`,
  );
}

function assertRawStableTrace(format, kind, trace) {
  const prefix = `${format} ${kind} raw stable`;
  const inserts = trace.events.filter((event) => event.type === 'wasm.insertTextInCellDeferredPagination');
  const effects = trace.events.filter((event) => event.type === 'InputHandler.prepareTextMutationBeforeCursor');
  const flushes = trace.events.filter((event) => event.type === 'wasm.flushDeferredPagination');
  const cursorQueries = trace.events.filter((event) => event.type === 'wasm.getCursorRectByPathNear');

  assert.equal(inserts.length, 1, `${prefix}: deferred insert count`);
  assert.equal(inserts[0].charOffset, TARGET.charOffset, `${prefix}: source offset`);
  assert.equal(inserts[0].resultCharOffset, TARGET.charOffset + 1, `${prefix}: result offset`);
  assert.equal(inserts[0].paginationDeferred, true, `${prefix}: deferred result`);
  assert.equal(inserts[0].cellFlowChanged, false, `${prefix}: stable flow result`);
  assert.equal(effects.length, 1, `${prefix}: consumed effect count`);
  assert.equal(effects[0].deferredPagination, true, `${prefix}: consumed deferred effect`);
  assert.equal(effects[0].cellFlowChanged, false, `${prefix}: consumed stable effect`);
  assert.equal(effects[0].paginationCompleted, false, `${prefix}: deferred completion state`);
  assert.equal(trace.counts.wasmBegin, 0, `${prefix}: stable input resumable begin count`);
  assert.equal(trace.counts.wasmStep, 0, `${prefix}: stable input resumable step count`);
  assert.equal(flushes.length, 0, `${prefix}: stable input flush count`);
  assert.ok(
    cursorQueries.some((event) => event.sequence > inserts[0].sequence),
    `${prefix}: cursor query after mutation`,
  );
}

async function dispatchRawInput(page, kind, text) {
  await page.evaluate(({ rawKind, rawText }) => {
    const input = window.__inputHandler;
    const textarea = input.textarea;
    if (rawKind === 'ime') {
      textarea.dispatchEvent(new CompositionEvent('compositionstart', { bubbles: true, data: '' }));
      textarea.value = rawText;
      textarea.dispatchEvent(new InputEvent('input', {
        bubbles: true,
        data: rawText,
        inputType: 'insertCompositionText',
        isComposing: true,
      }));
      textarea.dispatchEvent(new CompositionEvent('compositionend', { bubbles: true, data: rawText }));
      return;
    }

    input._isIOS = true;
    textarea.value = rawText;
    textarea.dispatchEvent(new InputEvent('input', {
      bubbles: true,
      data: rawText,
      inputType: 'insertText',
    }));
  }, { rawKind: kind, rawText: text });
}

async function runMultiUpdateImeSmoke(page, format, bytes) {
  await restoreTrace(page);
  await openDocumentThroughApp(page, format, bytes);
  await moveToTarget(page);
  const initial = await readFocusedSnapshot(page);
  const initialText = initial.model.text;
  await installTrace(page);

  await page.evaluate(() => {
    const textarea = window.__inputHandler.textarea;
    textarea.dispatchEvent(new CompositionEvent('compositionstart', {
      bubbles: true,
      data: '',
    }));
  });
  const durationsMs = [];
  for (const value of ['ㅎ', '하', '한']) {
    durationsMs.push(await page.evaluate((text) => {
      const textarea = window.__inputHandler.textarea;
      textarea.value = text;
      const startedAt = performance.now();
      textarea.dispatchEvent(new InputEvent('input', {
        bubbles: true,
        data: text,
        inputType: 'insertCompositionText',
        isComposing: true,
      }));
      return performance.now() - startedAt;
    }, value));
  }
  await page.evaluate(() => {
    const textarea = window.__inputHandler.textarea;
    textarea.dispatchEvent(new CompositionEvent('compositionend', {
      bubbles: true,
      data: '한',
    }));
  });
  await waitTwoRafs(page);

  const snapshot = await readFocusedSnapshot(page);
  assert.equal(snapshot.model.text, `${initialText}한`, `${format} multi-update IME final text`);
  assert.equal(snapshot.cursor.position.charOffset, TARGET.charOffset + 1, `${format} IME cursor offset`);
  assert.equal(snapshot.pagination.pageCount, 115, `${format} IME public page count`);
  assert.equal(snapshot.pagination.pending, true, `${format} IME deferred hold`);

  const trace = await collectTrace(page);
  // [#3412] #3254 이후 조합 갱신은 delete+insert 가 아니라 단일 replace 를 쓴다.
  // 첫 갱신(삭제 0)만 insert 로 남고, 2·3번째가 replace 두 번이 된다.
  const replacements = trace.events.filter(
    (event) => event.type === 'wasm.replaceTextInCellDeferredPagination',
  );
  assert.equal(trace.counts.deferredInsert, 1, `${format} IME deferred insert count`);
  assert.equal(trace.counts.deferredReplace, 2, `${format} IME deferred replacement count`);
  assert.equal(trace.counts.deferredDelete, 0, `${format} IME standalone delete count`);
  assert.equal(trace.counts.immediateDelete, 0, `${format} IME synchronous flat delete count`);
  assert.equal(trace.counts.pathDelete, 0, `${format} IME path delete count`);
  assert.equal(trace.counts.cursorRectInCell, 0, `${format} IME anchor cursor lookup count`);
  assert.equal(trace.counts.prepareTextMutation, 3, `${format} IME effect consumption count`);
  assert.equal(trace.counts.wasmFlush, 0, `${format} IME synchronous flush count`);
  // 두 치환 모두 조합 anchor 에서 직전 조합 글자 1개를 지우고 새 글자로 바꾼다.
  assert.deepEqual(replacements.map((event) => event.charOffset), [
    TARGET.charOffset,
    TARGET.charOffset,
  ]);
  assert.deepEqual(replacements.map((event) => event.deleteCount), [1, 1]);
  for (const [index, durationMs] of durationsMs.entries()) {
    assert.ok(durationMs < 250, `${format} IME update ${index + 1} blocked ${durationMs.toFixed(2)}ms`);
  }
  await restoreTrace(page);
  console.log(`  multi-update IME smoke: GREEN, updates=${durationsMs.map((v) => v.toFixed(1)).join('/')}ms`);
  return { format, durationsMs, traceCounts: trace.counts };
}

async function runImeAcrossPaginationCommitSmoke(page, format, bytes) {
  await restoreTrace(page);
  await openDocumentThroughApp(page, format, bytes);
  await moveToTarget(page);
  const initial = await readFocusedSnapshot(page);
  await typeKeyboardOnes(page, 55);
  await installTrace(page);

  const firstDurationMs = await page.evaluate(() => {
    const textarea = window.__inputHandler.textarea;
    textarea.dispatchEvent(new CompositionEvent('compositionstart', {
      bubbles: true,
      data: '',
    }));
    textarea.value = 'ㅎ';
    const startedAt = performance.now();
    textarea.dispatchEvent(new InputEvent('input', {
      bubbles: true,
      data: 'ㅎ',
      inputType: 'insertCompositionText',
      isComposing: true,
    }));
    return performance.now() - startedAt;
  });
  assert.equal(
    await page.evaluate(() => window.__inputHandler.hasDeferredPaginationPending()),
    true,
    `${format} IME pagination-commit precondition`,
  );

  await waitForDeferredPaginationCompletion(page);
  const afterCommit = await collectTrace(page);
  assert.equal(
    afterCommit.counts.cursorRectInCell,
    1,
    `${format} IME commit must refresh the invalidated anchor exactly once`,
  );

  const secondDurationMs = await page.evaluate(() => {
    const textarea = window.__inputHandler.textarea;
    textarea.value = '하';
    const startedAt = performance.now();
    textarea.dispatchEvent(new InputEvent('input', {
      bubbles: true,
      data: '하',
      inputType: 'insertCompositionText',
      isComposing: true,
    }));
    return performance.now() - startedAt;
  });
  await page.evaluate(() => {
    const textarea = window.__inputHandler.textarea;
    textarea.dispatchEvent(new CompositionEvent('compositionend', {
      bubbles: true,
      data: '하',
    }));
  });
  await waitTwoRafs(page);

  const snapshot = await readFocusedSnapshot(page);
  assert.equal(
    snapshot.model.text,
    `${initial.model.text}${'1'.repeat(55)}하`,
    `${format} IME pagination-commit final text`,
  );
  assert.equal(snapshot.cursor.position.charOffset, TARGET.charOffset + 56, `${format} IME commit cursor offset`);
  const trace = await collectTrace(page);
  assert.equal(
    trace.counts.cursorRectInCell,
    1,
    `${format} IME update after commit must reuse the refreshed anchor`,
  );
  assert.equal(trace.counts.immediateDelete, 0, `${format} IME commit synchronous delete count`);
  assert.equal(trace.counts.wasmFlush, 0, `${format} IME commit synchronous flush count`);
  await restoreTrace(page);
  console.log(
    `  IME pagination-commit smoke: GREEN, updates=${firstDurationMs.toFixed(1)}/${secondDurationMs.toFixed(1)}ms`,
  );
  return {
    format,
    firstDurationMs,
    secondDurationMs,
    cursorRectInCell: trace.counts.cursorRectInCell,
  };
}

async function runDeleteKeySmoke(page, format, bytes, key) {
  await restoreTrace(page);
  await openDocumentThroughApp(page, format, bytes);
  const charOffset = key === 'Delete' ? 64 : TARGET.charOffset;
  await page.evaluate(({ target, offset }) => {
    const input = window.__inputHandler;
    input.cursor.clearSelection();
    input.cursor.moveTo({ ...target, charOffset: offset });
    input.cursor.resetPreferredX();
    input.updateCaret();
    input.focus();
  }, { target: TARGET, offset: charOffset });
  const before = await readFocusedSnapshot(page);
  const expectedText = key === 'Delete'
    ? `${before.model.text.slice(0, charOffset)}${before.model.text.slice(charOffset + 1)}`
    : before.model.text.slice(0, -1);
  await installTrace(page);

  const startedAt = performance.now();
  await page.keyboard.press(key);
  const wallDurationMs = performance.now() - startedAt;
  await waitTwoRafs(page);

  const after = await readFocusedSnapshot(page);
  assert.equal(after.model.text, expectedText, `${format} ${key} final text`);
  assert.equal(
    after.cursor.position.charOffset,
    key === 'Delete' ? charOffset : charOffset - 1,
    `${format} ${key} cursor offset`,
  );
  assert.equal(after.pagination.pageCount, 115, `${format} ${key} public page count`);
  assert.equal(after.pagination.pending, true, `${format} ${key} deferred hold`);

  const trace = await collectTrace(page);
  const deferred = trace.events.filter((event) => event.type === 'wasm.deleteTextInCellDeferredPagination');
  assert.equal(deferred.length, 1, `${format} ${key} deferred delete count`);
  assert.equal(trace.counts.immediateDelete, 0, `${format} ${key} synchronous delete count`);
  assert.equal(trace.counts.pathDelete, 0, `${format} ${key} path delete count`);
  assert.equal(trace.counts.wasmFlush, 0, `${format} ${key} synchronous flush count`);
  assert.ok(deferred[0].durationMs < 250, `${format} ${key} WASM blocked ${deferred[0].durationMs.toFixed(2)}ms`);
  assert.ok(wallDurationMs < 500, `${format} ${key} key event blocked ${wallDurationMs.toFixed(2)}ms`);
  await restoreTrace(page);
  console.log(`  ${key} smoke: GREEN, wasm=${deferred[0].durationMs.toFixed(1)}ms`);
  return { format, key, wallDurationMs, wasmDurationMs: deferred[0].durationMs };
}

async function runRawStableSmoke(page, format, bytes, kind) {
  await restoreTrace(page);
  await openDocumentThroughApp(page, format, bytes);
  await moveToTarget(page);
  const initial = await readFocusedSnapshot(page);
  const initialText = initial.model.text;
  assert.equal(initialText.length, TARGET.charOffset, `${format} ${kind} stable: initial text length`);

  await installTrace(page);
  await dispatchRawInput(page, kind, '1');
  await delay(page, 150);
  await waitTwoRafs(page);

  const timelineStart = await page.evaluate(() => performance.now());
  const finalState = await collectState(page, `${kind}-raw-stable-after-150ms`, timelineStart);
  assertExactFocusedState(
    format,
    `${kind}-raw-stable`,
    finalState,
    `${initialText}1`,
    4,
    945.9,
    true,
  );
  const trace = await collectTrace(page);
  assertRawStableTrace(format, kind, trace);

  if (kind === 'ios') {
    await page.evaluate(() => {
      window.__inputHandler._isIOS = false;
    });
  }
  await restoreTrace(page);
  console.log(`  ${kind} raw stable smoke: GREEN, flush=0`);
  return {
    format,
    kind,
    variant: 'stable',
    finalLength: finalState.model.length,
    pageCount: finalState.pagination.pageCount,
    flushCount: trace.counts.wasmFlush,
  };
}

async function runRawBoundarySmoke(page, format, bytes, kind) {
  await restoreTrace(page);
  await openDocumentThroughApp(page, format, bytes);
  await moveToTarget(page);
  const initial = await readFocusedSnapshot(page);
  const initialText = initial.model.text;
  assert.equal(initialText.length, TARGET.charOffset, `${format} ${kind}: initial text length`);

  await typeKeyboardOnes(page, 55);
  const beforeBoundary = await readFocusedSnapshot(page);
  assertFocusedSnapshot(
    format,
    `${kind}-raw`,
    55,
    beforeBoundary,
    `${initialText}${'1'.repeat(55)}`,
  );

  await installTrace(page);
  await dispatchRawInput(page, kind, '1');

  const completionWaitMs = await waitForDeferredPaginationCompletion(page);
  await waitTwoRafs(page);
  const finalText = `${initialText}${'1'.repeat(56)}`;
  const timelineStart = await page.evaluate(() => performance.now());
  const finalState = await collectState(page, `${kind}-raw-after-complete`, timelineStart);
  assertExactFocusedState(
    format,
    `${kind}-raw`,
    finalState,
    finalText,
    5,
    945.9,
    false,
  );
  const trace = await collectTrace(page);
  assertRawBoundaryTrace(format, kind, trace);

  if (kind === 'ios') {
    await page.evaluate(() => {
      window.__inputHandler._isIOS = false;
    });
  }
  await restoreTrace(page);
  console.log(`  ${kind} raw smoke: GREEN, flush=0, steps=${trace.counts.wasmStep}`);
  return {
    format,
    kind,
    variant: 'boundary',
    finalLength: finalState.model.length,
    pageCount: finalState.pagination.pageCount,
    flushCount: trace.counts.wasmFlush,
    stepCount: trace.counts.wasmStep,
    completionWaitMs,
  };
}

async function triggerFileMenuCommand(page, commandId) {
  return page.evaluate((id) => {
    const fileItem = [...document.querySelectorAll('#menu-bar .menu-item')]
      .find((element) => (element.textContent || '').includes('파일'));
    const title = fileItem?.querySelector('.menu-title');
    if (!title) return { ok: false, reason: 'file menu title missing' };
    title.dispatchEvent(new MouseEvent('mousedown', { bubbles: true, cancelable: true }));
    const command = document.querySelector(`.md-item[data-cmd="${id}"]`);
    if (!command) return { ok: false, reason: `${id} menu item missing` };
    if (command.classList.contains('disabled')) {
      return { ok: false, reason: `${id} menu item disabled` };
    }
    command.dispatchEvent(new MouseEvent('click', { bubbles: true, cancelable: true }));
    return { ok: true };
  }, commandId);
}

async function preparePendingBoundary(page, format, bytes) {
  await restoreTrace(page);
  await openDocumentThroughApp(page, format, bytes);
  await moveToTarget(page);
  const boundaryInput = process.argv.includes('--output-barriers-only') && format === 'hwpx' ? 61 : 56;
  await typeKeyboardOnes(page, boundaryInput - 1);
  await installTrace(page);
  await page.keyboard.type('1');
  const state = await readFocusedSnapshot(page);
  state.barrierInputCount = boundaryInput;
  assert.equal(state.pagination.pending, true, `${format} output barrier precondition`);
  assert.equal(state.model.text.slice(-boundaryInput), '1'.repeat(boundaryInput), `${format} output latest text precondition`);
  return state;
}

async function runSaveBarrierSmoke(page, format, bytes) {
  const before = await preparePendingBoundary(page, format, bytes);
  await page.evaluate(() => {
    try { delete window.showSaveFilePicker; } catch { window.showSaveFilePicker = undefined; }
    window.__issue2424SavedBlob = null;
    window.__issue2424OriginalCreateObjectURL ??= URL.createObjectURL.bind(URL);
    URL.createObjectURL = (blob) => {
      window.__issue2424SavedBlob = blob;
      return 'blob:issue-2424-captured';
    };
    HTMLAnchorElement.prototype.click = function issue2424NoDownload() {};
  });

  const triggered = await triggerFileMenuCommand(page, 'file:save');
  assert.equal(triggered.ok, true, `${format} save trigger: ${triggered.reason ?? ''}`);
  await page.waitForFunction(() => window.__issue2424SavedBlob instanceof Blob, { timeout: 60_000 });

  const trace = await collectTrace(page);
  const flush = trace.events.find((event) => event.type === 'wasm.flushDeferredPagination');
  const exportType = format === 'hwpx' ? 'wasm.exportHwpx' : 'wasm.exportHwp';
  const exported = trace.events.find((event) => event.type === exportType || event.type === `${exportType}WithReport`);
  assert.ok(flush, `${format} save flush event`);
  assert.ok(exported, `${format} save export event`);
  assert.ok(flush.sequence < exported.sequence, `${format} save must flush before serialization`);
  assert.equal(trace.counts.wasmFlush, 1, `${format} save flush count`);
  assert.equal(
    await page.evaluate(() => window.__inputHandler.hasDeferredPaginationPending()),
    false,
    `${format} save pending state`,
  );

  const postExportPageCount = await page.evaluate(() => window.__wasm.pageCount);
  const saved = await page.evaluate(async ({ target, sourceFormat, inputCount }) => {
    const buffer = await window.__issue2424SavedBlob.arrayBuffer();
    const bytes = new Uint8Array(buffer);
    const info = window.__wasm.loadDocument(bytes, `issue2424-saved.${sourceFormat}`);
    const length = window.__wasm.getCellParagraphLength(
      target.sectionIndex,
      target.parentParaIndex,
      target.controlIndex,
      target.cellIndex,
      target.cellParaIndex,
    );
    const text = window.__wasm.getTextInCell(
      target.sectionIndex,
      target.parentParaIndex,
      target.controlIndex,
      target.cellIndex,
      target.cellParaIndex,
      0,
      length,
    );
    return {
      byteLength: bytes.byteLength,
      pageCount: info.pageCount,
      textTail: text.slice(-inputCount),
      bytesBase64: btoa(Array.from(bytes, b => String.fromCharCode(b)).join('')),
    };
  }, { target: TARGET, sourceFormat: format, inputCount: before.barrierInputCount });
  if (process.argv.includes('--output-barriers-only')) {
    const { bytesBase64, ...metadata } = saved;
    const savedBytes = Buffer.from(bytesBase64, 'base64');
    writeFileSync(path.join(OUTPUT_ROOT, `saved-reopen.${format}`), savedBytes);
    writeJson(path.join(OUTPUT_ROOT, `${format}-save-evidence.json`), {
      beforePageCount: before.pagination.pageCount, postExportPageCount, inputCount: before.barrierInputCount,
      saved: metadata, sha256: sha256(savedBytes),
      flushSequence: flush.sequence, exportSequence: exported.sequence,
      flushCount: trace.counts.wasmFlush,
    });
  }
  delete saved.bytesBase64;
  assert.ok(saved.byteLength > 0, `${format} saved bytes`);
  assert.equal(saved.pageCount, before.pagination.pageCount, `${format} saved final page count`);
  assert.equal(saved.textTail, '1'.repeat(before.barrierInputCount), `${format} saved latest cell text`);
  await restoreTrace(page);
  console.log(`  save barrier: GREEN, flush→${format} export, bytes=${saved.byteLength}`);
  return { format, saved, flushSequence: flush.sequence, exportSequence: exported.sequence };
}

async function runPrintBarrierSmoke(page, format, bytes) {
  const before = await preparePendingBoundary(page, format, bytes);
  await page.evaluate(() => {
    // [#3412] 인쇄 미리보기는 별도 창(print.html surface)을 열고 load 이벤트·origin·rAF 를
    // 사용한다. 가짜 창이 document/print/close 만 갖고 있으면 createPrintPreviewSurface 가
    // addEventListener 에서 죽어 페이지가 한 장도 안 그려진다.
    const printDocument = document.implementation.createHTMLDocument('issue-2424-print');
    try {
      Object.defineProperty(printDocument, 'readyState', { value: 'complete', configurable: true });
    } catch {
      // readyState 를 덮어쓸 수 없으면 load 이벤트 경로로 넘어간다.
    }
    const surfaceUrl = new URL('print.html', document.baseURI).href;
    window.__issue2424PrintWindow = {
      document: printDocument,
      location: { href: surfaceUrl, origin: window.location.origin },
      closed: false,
      addEventListener() {},
      removeEventListener() {},
      requestAnimationFrame(callback) {
        return window.requestAnimationFrame(callback);
      },
      print() {},
      close() {
        this.closed = true;
      },
    };
    window.open = () => window.__issue2424PrintWindow;
  });

  const triggered = await triggerFileMenuCommand(page, 'file:print');
  assert.equal(triggered.ok, true, `${format} print trigger: ${triggered.reason ?? ''}`);
  await page.waitForFunction(
    (pageCount) => window.__issue2424PrintWindow?.document?.querySelectorAll('.page').length === pageCount,
    { timeout: 120_000 },
    before.pagination.pageCount,
  );
  const trace = await collectTrace(page);
  const flush = trace.events.find((event) => event.type === 'wasm.flushDeferredPagination');
  const firstRender = trace.events.find(
    (event) => event.type === 'wasm.renderPageSvg' || event.type === 'wasm.renderPageSvgWithProfile',
  );
  assert.ok(flush, `${format} print flush event`);
  assert.ok(firstRender, `${format} print render event`);
  assert.ok(flush.sequence < firstRender.sequence, `${format} print must flush before first page render`);
  assert.equal(trace.counts.wasmFlush, 1, `${format} print flush count`);
  assert.equal(trace.counts.renderPageSvg, before.pagination.pageCount, `${format} print rendered page count`);

  const output = await page.evaluate(() => ({
    pageCount: window.__issue2424PrintWindow.document.querySelectorAll('.page').length,
    // [#3412] 402d6342c 에서 미리보기 바가 print-preview-bar/print-preview-title 로 바뀌고
    // 라벨도 `파일명 — N쪽` 형식이 됐다.
    printBarLabel: window.__issue2424PrintWindow.document
      .querySelector('.print-preview-bar .print-preview-title')?.textContent ?? '',
    pending: window.__inputHandler.hasDeferredPaginationPending(),
  }));
  assert.equal(output.pageCount, before.pagination.pageCount, `${format} print final page count`);
  assert.match(output.printBarLabel, /115쪽/, `${format} print bar page count`);
  assert.equal(output.pending, false, `${format} print pending state`);
  await restoreTrace(page);
  console.log(`  print barrier: GREEN, flush→render ${output.pageCount} pages`);
  return { format, output, flushSequence: flush.sequence, firstRenderSequence: firstRender.sequence };
}

async function runFocusedMain() {
  const formats = cliValue('formats', 'hwp,hwpx')
    .split(',')
    .map((value) => value.trim().toLowerCase())
    .filter(Boolean);
  const runs = Number(cliValue('runs', '3'));
  const reviewOnly = process.argv.includes('--review-only');
  const continuousOnly = process.argv.includes('--continuous-only');
  assert.ok(Number.isInteger(runs) && runs > 0, '--runs must be a positive integer');
  assert.equal(
    reviewOnly && continuousOnly,
    false,
    '--review-only and --continuous-only are mutually exclusive',
  );
  for (const format of formats) assert.ok(SAMPLES[format], `unsupported format: ${format}`);

  mkdirSync(OUTPUT_ROOT, { recursive: true });
  const fixtures = Object.fromEntries(formats.map((format) => {
    const bytes = readFileSync(SAMPLES[format]);
    return [format, {
      path: SAMPLES[format],
      bytes,
      size: bytes.length,
      sha256: sha256(bytes),
    }];
  }));

  const browser = await launchBrowser();
  const page = await createPage(browser, 1280, 900);
  page.on('console', (message) => {
    if (message.type() === 'error' || message.type() === 'warning') {
      console.log(`  [browser:${message.type()}] ${message.text()}`);
    }
  });
  page.on('pageerror', (error) => console.log(`  [browser:pageerror] ${error.message}`));

  const startedAt = new Date().toISOString();
  const results = [];
  const rawSmokes = [];
  const continuousSmokes = [];
  const reviewSmokes = [];
  try {
    await loadApp(page);
    for (const format of formats) {
      if (!reviewOnly && !continuousOnly) {
        console.log(`\n[${format.toUpperCase()}] focused GREEN (${runs} runs)`);
        for (let runNumber = 1; runNumber <= runs; runNumber += 1) {
          results.push(await runFocusedFormat(page, format, fixtures[format].bytes, runNumber));
        }
      }
      if (!reviewOnly) {
        console.log(`\n[${format.toUpperCase()}] continuous IME→digit second-wrap`);
        continuousSmokes.push(await runContinuousImeDigitSmoke(page, format, fixtures[format].bytes));
      }
      if (!reviewOnly && !continuousOnly) {
        rawSmokes.push(await runRawStableSmoke(page, format, fixtures[format].bytes, 'ime'));
        rawSmokes.push(await runRawStableSmoke(page, format, fixtures[format].bytes, 'ios'));
        rawSmokes.push(await runRawBoundarySmoke(page, format, fixtures[format].bytes, 'ime'));
        rawSmokes.push(await runRawBoundarySmoke(page, format, fixtures[format].bytes, 'ios'));
      }
      if (!continuousOnly) {
        console.log(`\n[${format.toUpperCase()}] #2424 deletion/IME/output barrier`);
        reviewSmokes.push(await runDeleteKeySmoke(page, format, fixtures[format].bytes, 'Backspace'));
        reviewSmokes.push(await runDeleteKeySmoke(page, format, fixtures[format].bytes, 'Delete'));
        reviewSmokes.push(await runMultiUpdateImeSmoke(page, format, fixtures[format].bytes));
        reviewSmokes.push(await runImeAcrossPaginationCommitSmoke(page, format, fixtures[format].bytes));
        reviewSmokes.push(await runSaveBarrierSmoke(page, format, fixtures[format].bytes));
        if (format === 'hwp') {
          reviewSmokes.push(await runPrintBarrierSmoke(page, format, fixtures[format].bytes));
        }
      }
    }
  } finally {
    await restoreTrace(page).catch(() => {});
    await closePage(page).catch(() => {});
    await closeBrowser(browser).catch(() => {});
  }

  const summary = {
    issue: 2214,
    mode: 'focused-green',
    startedAt,
    finishedAt: new Date().toISOString(),
    environment: {
      viteUrl: process.env.VITE_URL ?? 'http://localhost:7700',
      chromePath: process.env.CHROME_PATH ?? process.env.PUPPETEER_EXECUTABLE_PATH ?? null,
      viewport: { width: 1280, height: 900, deviceScaleFactor: 1 },
      runs,
      continuousOnly,
    },
    fixtures: Object.fromEntries(Object.entries(fixtures).map(([format, value]) => [format, {
      path: value.path,
      size: value.size,
      sha256: value.sha256,
    }])),
    results,
    rawSmokes,
    continuousSmokes,
    reviewSmokes,
  };
  writeJson(path.join(OUTPUT_ROOT, 'focused-summary.json'), summary);
  console.log(`\nIssue #2214 focused GREEN written to ${OUTPUT_ROOT}`);
}

async function runDiagnosticMain() {
  assert.ok(process.argv.includes('--diagnose'), 'Stage 1 runner requires --diagnose');
  const formats = cliValue('formats', 'hwp,hwpx')
    .split(',')
    .map((value) => value.trim().toLowerCase())
    .filter(Boolean);
  const discoveryRuns = Number(cliValue('runs', '3'));
  assert.ok(Number.isInteger(discoveryRuns) && discoveryRuns > 0, '--runs must be a positive integer');
  for (const format of formats) assert.ok(SAMPLES[format], `unsupported format: ${format}`);

  mkdirSync(OUTPUT_ROOT, { recursive: true });
  const fixtures = Object.fromEntries(formats.map((format) => {
    const bytes = readFileSync(SAMPLES[format]);
    return [format, {
      path: SAMPLES[format],
      bytes,
      size: bytes.length,
      sha256: sha256(bytes),
    }];
  }));

  const browser = await launchBrowser();
  const page = await createPage(browser, 1280, 900);
  page.on('console', (message) => {
    if (message.type() === 'error' || message.type() === 'warning') {
      console.log(`  [browser:${message.type()}] ${message.text()}`);
    }
  });
  page.on('pageerror', (error) => console.log(`  [browser:pageerror] ${error.message}`));

  const startedAt = new Date().toISOString();
  const results = [];
  try {
    await loadApp(page);
    for (const format of formats) {
      results.push(await runFormat(page, format, fixtures[format].bytes, discoveryRuns));
    }
  } finally {
    await restoreTrace(page).catch(() => {});
    await closePage(page).catch(() => {});
    await closeBrowser(browser).catch(() => {});
  }

  const summary = {
    issue: 2214,
    mode: 'diagnose',
    startedAt,
    finishedAt: new Date().toISOString(),
    environment: {
      viteUrl: process.env.VITE_URL ?? 'http://localhost:7700',
      chromePath: process.env.CHROME_PATH ?? process.env.PUPPETEER_EXECUTABLE_PATH ?? null,
      viewport: { width: 1280, height: 900, deviceScaleFactor: 1 },
      discoveryRuns,
    },
    fixtures: Object.fromEntries(Object.entries(fixtures).map(([format, value]) => [format, {
      path: value.path,
      size: value.size,
      sha256: value.sha256,
    }])),
    formats: results.map((result) => ({
      format: result.format,
      transitionAt: result.transitionAt,
      discoveryNs: result.discoveries.map((value) => value.transitionAt),
      classification: result.classification,
    })),
  };
  writeJson(path.join(OUTPUT_ROOT, 'summary.json'), summary);
  console.log(`\nIssue #2214 diagnostic written to ${OUTPUT_ROOT}`);
  console.log(JSON.stringify(summary.formats, null, 2));
}

async function runOutputBarriersOnly() {
  mkdirSync(OUTPUT_ROOT, { recursive: true });
  const browser = await launchBrowser();
  const page = await createPage(browser, 1280, 900);
  const results = [];
  try {
    await loadApp(page);
    for (const format of ['hwp', 'hwpx']) {
      const bytes = readFileSync(SAMPLES[format]);
      for (const kind of format === 'hwp' ? ['save', 'print'] : ['save']) {
        if (!cliValue('output-barrier-cases', 'hwp:save,hwp:print,hwpx:save').split(',').includes(`${format}:${kind}`)) continue;
        try {
          const result = kind === 'save'
            ? await runSaveBarrierSmoke(page, format, bytes)
            : await runPrintBarrierSmoke(page, format, bytes);
          results.push({ format, kind, status: 'pass', result });
        } catch (error) {
          results.push({ format, kind, status: 'fail', error: error.stack ?? String(error) });
        }
        writeJson(path.join(OUTPUT_ROOT, 'output-barriers.json'), { results });
      }
    }
  } finally {
    await restoreTrace(page).catch(() => {});
    await closePage(page).catch(() => {});
    await closeBrowser(browser).catch(() => {});
  }
  assert.ok(results.every(r => r.status === 'pass'), JSON.stringify(results));
}

const selectedMain = process.argv.includes('--output-barriers-only') ? runOutputBarriersOnly
  : process.argv.includes('--diagnose') ? runDiagnosticMain : runFocusedMain;
selectedMain().catch((error) => {
  console.error(error);
  process.exitCode = 1;
});
