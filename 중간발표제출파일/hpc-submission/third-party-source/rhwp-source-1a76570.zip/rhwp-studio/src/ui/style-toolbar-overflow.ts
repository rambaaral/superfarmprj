import { getLocale } from '../i18n/core.ts';

import { t } from '../i18n/index.ts';
export const STYLE_TOOLBAR_FULL_ROW_MIN = 962;
export const STYLE_TOOLBAR_COMMAND_INLINE_MIN = 460;
export const STYLE_TOOLBAR_ONE_ROW_MIN = 808;
export const STYLE_TOOLBAR_OVERFLOW_QUERY = `(max-width: ${STYLE_TOOLBAR_COMMAND_INLINE_MIN - 1}px), (min-width: ${STYLE_TOOLBAR_ONE_ROW_MIN}px) and (max-width: ${STYLE_TOOLBAR_FULL_ROW_MIN - 1}px)`;

// 영어 Font Set 열에 추가한 20px를 CSS의 828px / 982px 경계와 함께 반영한다.
export const STYLE_TOOLBAR_EN_OVERFLOW_QUERY = `(max-width: ${STYLE_TOOLBAR_COMMAND_INLINE_MIN - 1}px), (min-width: ${STYLE_TOOLBAR_ONE_ROW_MIN + 20}px) and (max-width: ${STYLE_TOOLBAR_FULL_ROW_MIN + 20 - 1}px)`;

const PARAGRAPH_BUTTON_SELECTOR = '.sb-paragraph-ribbon-group .sb-btn';
const DEFAULT_ALIGNMENT_ICON = 'sb-al-left';
const ALIGNMENT_ICON_CLASSES = [
  'sb-al-left',
  'sb-al-center',
  'sb-al-right',
  'sb-al-justify',
  'sb-al-distribute',
  'sb-al-split',
] as const;

export function shouldReturnStyleToolbarFocus(
  openedFromKeyboard: boolean,
  pointerActivation: boolean,
): boolean {
  return openedFromKeyboard && !pointerActivation;
}

/**
 * 한 줄에서 문단 명령까지 담기 어렵거나 아주 좁은 화면일 때 같은 DOM을 더보기 panel에 노출한다.
 *
 * CSS가 inline 구간에서는 host/panel을 display:contents로 풀기 때문에 runtime reparent나 command
 * 복제가 필요 없다. controller는 compact 구간의 open/focus/접근성 상태만 소유한다.
 */
export class StyleToolbarOverflowController {
  private readonly container: HTMLElement;
  private readonly host: HTMLElement;
  private readonly trigger: HTMLButtonElement;
  private readonly triggerIcon: HTMLElement;
  private readonly panel: HTMLElement;
  private readonly mediaQuery: MediaQueryList;
  private readonly paragraphButtons: HTMLButtonElement[];
  private readonly stateObserver: MutationObserver;
  private open = false;
  private openedFromKeyboard = false;
  private triggerPointerActivation = false;
  private panelPointerActivation = false;

  private readonly onTriggerPointerDown = (): void => {
    this.triggerPointerActivation = true;
  };

  private readonly onTriggerClick = (): void => {
    const opening = !this.open;
    const keyboardActivation = !this.triggerPointerActivation;
    this.triggerPointerActivation = false;
    this.openedFromKeyboard = opening && keyboardActivation;
    this.setOpen(opening, opening && keyboardActivation);
  };

  private readonly onTriggerKeyDown = (event: KeyboardEvent): void => {
    if (event.key !== 'ArrowDown') return;
    event.preventDefault();
    this.openedFromKeyboard = true;
    this.setOpen(true, true);
  };

  private readonly onPanelPointerDown = (): void => {
    this.panelPointerActivation = true;
  };

  private readonly onPanelClick = (event: MouseEvent): void => {
    const target = event.target;
    if (!(target instanceof Element) || !target.closest(PARAGRAPH_BUTTON_SELECTOR)) return;
    const returnFocus = shouldReturnStyleToolbarFocus(
      this.openedFromKeyboard,
      this.panelPointerActivation,
    );
    this.panelPointerActivation = false;
    this.openedFromKeyboard = false;
    this.setOpen(false, false, returnFocus);
  };

  private readonly onDocumentPointerDown = (event: PointerEvent): void => {
    const target = event.target;
    if (!this.open || !(target instanceof Node) || this.host.contains(target)) return;
    this.setOpen(false);
  };

  private readonly onWindowKeyDown = (event: KeyboardEvent): void => {
    if (!this.open || event.key !== 'Escape') return;
    event.preventDefault();
    event.stopPropagation();
    this.setOpen(false, false, true);
  };

  private readonly onMediaChange = (): void => {
    this.syncLayoutMode();
  };

  constructor(
    container: HTMLElement,
    host: HTMLElement,
    trigger: HTMLButtonElement,
    triggerIcon: HTMLElement,
    panel: HTMLElement,
    matchMedia: (query: string) => MediaQueryList = window.matchMedia.bind(window),
  ) {
    this.container = container;
    this.host = host;
    this.trigger = trigger;
    this.triggerIcon = triggerIcon;
    this.panel = panel;
    this.mediaQuery = matchMedia(getLocale() === 'en'
      ? STYLE_TOOLBAR_EN_OVERFLOW_QUERY
      : STYLE_TOOLBAR_OVERFLOW_QUERY);
    this.paragraphButtons = Array.from(
      panel.querySelectorAll<HTMLButtonElement>(PARAGRAPH_BUTTON_SELECTOR),
    );
    this.stateObserver = new MutationObserver(() => this.syncIndicator());

    trigger.addEventListener('pointerdown', this.onTriggerPointerDown);
    trigger.addEventListener('click', this.onTriggerClick);
    trigger.addEventListener('keydown', this.onTriggerKeyDown);
    panel.addEventListener('pointerdown', this.onPanelPointerDown);
    panel.addEventListener('click', this.onPanelClick);
    document.addEventListener('pointerdown', this.onDocumentPointerDown, true);
    window.addEventListener('keydown', this.onWindowKeyDown, true);
    this.mediaQuery.addEventListener('change', this.onMediaChange);
    this.stateObserver.observe(panel, {
      attributes: true,
      subtree: true,
      attributeFilter: ['class', 'disabled', 'aria-pressed'],
    });
    this.stateObserver.observe(container, {
      attributes: true,
      attributeFilter: ['aria-disabled'],
    });

    this.syncLayoutMode();
    this.syncIndicator();
  }

  private syncLayoutMode(): void {
    this.open = false;
    this.openedFromKeyboard = false;
    this.host.classList.remove('open');
    this.trigger.setAttribute('aria-expanded', 'false');
    this.panel.hidden = this.mediaQuery.matches;
  }

  private setOpen(next: boolean, focusFirst = false, returnFocus = false): void {
    const open = this.mediaQuery.matches && next;
    this.open = open;
    this.host.classList.toggle('open', open);
    this.trigger.setAttribute('aria-expanded', String(open));
    this.panel.hidden = this.mediaQuery.matches ? !open : false;

    if (open && focusFirst) {
      requestAnimationFrame(() => this.paragraphButtons.find(button => !button.disabled)?.focus());
    } else if (!open && returnFocus) {
      this.trigger.focus({ preventScroll: true });
    }
  }

  private syncIndicator(): void {
    const activeCommand = this.paragraphButtons.find(button =>
      button.classList.contains('active') || button.getAttribute('aria-pressed') === 'true',
    );
    const activeCommandIcon = activeCommand?.querySelector<HTMLElement>('.sb-align');
    const activeIconClass = ALIGNMENT_ICON_CLASSES.find(iconClass =>
      activeCommandIcon?.classList.contains(iconClass),
    ) ?? DEFAULT_ALIGNMENT_ICON;
    const toolbarDisabled = this.container.getAttribute('aria-disabled') === 'true';

    this.triggerIcon.classList.remove(...ALIGNMENT_ICON_CLASSES);
    this.triggerIcon.classList.add(activeIconClass);
    this.trigger.disabled = toolbarDisabled;
    const currentAlignment = activeCommand?.title;
    const accessibleLabel = currentAlignment
      ? t('ui.styleToolbarOverflow.alignMoreCurrent', { p1: currentAlignment })
      : t('ui.styleToolbarOverflow.alignMore');
    this.trigger.setAttribute('aria-label', accessibleLabel);
    this.trigger.title = currentAlignment
      ? t('dialog.styleToolbarOverflow.trigger.tooltip', { p1: currentAlignment })
      : t('dialog.styleToolbarOverflow.syncIndicator.tooltip');
  }

  dispose(): void {
    this.setOpen(false);
    this.trigger.removeEventListener('pointerdown', this.onTriggerPointerDown);
    this.trigger.removeEventListener('click', this.onTriggerClick);
    this.trigger.removeEventListener('keydown', this.onTriggerKeyDown);
    this.panel.removeEventListener('pointerdown', this.onPanelPointerDown);
    this.panel.removeEventListener('click', this.onPanelClick);
    document.removeEventListener('pointerdown', this.onDocumentPointerDown, true);
    window.removeEventListener('keydown', this.onWindowKeyDown, true);
    this.mediaQuery.removeEventListener('change', this.onMediaChange);
    this.stateObserver.disconnect();
  }
}

export function initStyleToolbarOverflow(container: HTMLElement | null): StyleToolbarOverflowController | null {
  if (!container) return null;
  const host = container.querySelector<HTMLElement>('.sb-overflow-host');
  const trigger = container.querySelector<HTMLButtonElement>('#btn-style-overflow');
  const triggerIcon = container.querySelector<HTMLElement>('#style-overflow-current-icon');
  const panel = container.querySelector<HTMLElement>('#style-overflow-panel');
  if (!host || !trigger || !triggerIcon || !panel) {
    return null;
  }
  return new StyleToolbarOverflowController(container, host, trigger, triggerIcon, panel);
}
