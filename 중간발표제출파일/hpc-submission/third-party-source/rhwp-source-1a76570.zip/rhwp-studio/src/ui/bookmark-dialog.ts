/**
 * 책갈피 대화상자
 *
 * 책갈피 추가/이동/삭제/이름 바꾸기를 수행한다.
 */
import type { CommandServices } from '@/command/types';
import type { BookmarkInfo } from '@/core/types';
import { enableDialogDrag } from './dialog-drag';

import { t } from '../i18n/index.ts';
type SortMode = 'name' | 'position';

// [Task #2862] 책갈피 이름은 HWP5 CTRL_DATA 레코드에서 u16 길이 프리픽스로 직렬화된다
// (`src/serializer/control.rs`의 `serialize_bookmark_ctrl_data`, `utf16.len() as u16`).
// UTF-16 코드 유닛 65536개 이상이면 길이 프리픽스가 랩어라운드되어 저장 파일이 손상되므로
// (#2851/#2854와 동일한 원인), 프런트엔드에서 여유를 둔 상한으로 미리 차단한다.
export const MAX_BOOKMARK_NAME_LEN = 250;

export class BookmarkDialog {
  private services: CommandServices;
  private _open = false;
  private overlay!: HTMLDivElement;
  private dialog!: HTMLDivElement;
  private nameInput!: HTMLInputElement;
  private listEl!: HTMLDivElement;
  private statusLabel!: HTMLSpanElement;
  private sortMode: SortMode = 'position';
  private bookmarks: BookmarkInfo[] = [];
  private selectedIdx = -1;
  private captureHandler: ((e: KeyboardEvent) => void) | null = null;

  constructor(services: CommandServices) {
    this.services = services;
  }

  isOpen(): boolean { return this._open; }

  show(): void {
    if (this._open) { this.nameInput?.focus(); return; }
    this._open = true;
    this.build();
    document.body.appendChild(this.overlay);

    this.captureHandler = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        e.stopPropagation(); e.preventDefault();
        this.hide(); return;
      }
      e.stopPropagation();
    };
    document.addEventListener('keydown', this.captureHandler, true);

    // 싱글턴으로 재사용되는데 build() 가 라디오를 매번 '위치(P)' 체크 상태로 새로
    // 만들므로, 이전 세션의 sortMode('name')가 남으면 라디오 표시와 실제 목록
    // 정렬이 어긋난다 — 라디오 초기 상태와 일치하도록 리셋한다. (#3144)
    this.sortMode = 'position';

    this.refreshList();
    this.suggestName();
    this.nameInput.focus();
    this.nameInput.select();
  }

  hide(): void {
    if (this.captureHandler) {
      document.removeEventListener('keydown', this.captureHandler, true);
      this.captureHandler = null;
    }
    this._open = false;
    this.overlay?.remove();
    this.services.getInputHandler()?.focus();
  }

  // ── DOM 구성 ──

  private build(): void {
    this.overlay = document.createElement('div');
    this.overlay.className = 'modal-overlay';

    this.dialog = document.createElement('div');
    this.dialog.className = 'dialog-wrap bm-dialog';

    // 타이틀
    const titleBar = document.createElement('div');
    titleBar.className = 'dialog-title';
    titleBar.textContent = t('dialog.bookmark.titleBar.text');
    const closeBtn = document.createElement('button');
    closeBtn.className = 'dialog-close';
    closeBtn.textContent = '\u00D7';
    closeBtn.addEventListener('click', () => this.hide());
    titleBar.appendChild(closeBtn);
    this.dialog.appendChild(titleBar);
    enableDialogDrag(this.dialog, titleBar);

    // 본문
    const body = document.createElement('div');
    body.className = 'dialog-body bm-body';

    // 이름 입력 행
    const nameRow = document.createElement('div');
    nameRow.className = 'bm-row';
    const nameLabel = document.createElement('label');
    nameLabel.className = 'bm-label';
    nameLabel.textContent = t('dialog.bookmark.nameLabel.text');
    this.nameInput = document.createElement('input');
    this.nameInput.type = 'text';
    this.nameInput.className = 'bm-name-input';
    this.nameInput.maxLength = MAX_BOOKMARK_NAME_LEN;
    this.nameInput.addEventListener('keydown', (e) => {
      if (e.key === 'Enter') { e.preventDefault(); this.doAdd(); }
    });
    nameRow.appendChild(nameLabel);
    nameRow.appendChild(this.nameInput);
    body.appendChild(nameRow);

    // 목록 헤더 + 버튼 영역
    const midRow = document.createElement('div');
    midRow.className = 'bm-mid';

    const listCol = document.createElement('div');
    listCol.className = 'bm-list-col';
    const listLabel = document.createElement('div');
    listLabel.className = 'bm-label';
    listLabel.textContent = t('dialog.bookmark.listLabel.text');
    listCol.appendChild(listLabel);

    // 목록 헤더
    const listHeader = document.createElement('div');
    listHeader.className = 'bm-list-header';
    const hName = document.createElement('span');
    hName.textContent = t('dialog.bookmark.hName.text');
    hName.className = 'bm-list-hcol';
    const hType = document.createElement('span');
    hType.textContent = t('dialog.bookmark.hType.text');
    hType.className = 'bm-list-hcol bm-list-hcol-type';
    listHeader.appendChild(hName);
    listHeader.appendChild(hType);
    listCol.appendChild(listHeader);

    // 목록 본문
    this.listEl = document.createElement('div');
    this.listEl.className = 'bm-list';
    listCol.appendChild(this.listEl);

    // 상태 라벨
    this.statusLabel = document.createElement('div');
    this.statusLabel.className = 'bm-status';
    listCol.appendChild(this.statusLabel);

    midRow.appendChild(listCol);

    // 버튼 컬럼
    const btnCol = document.createElement('div');
    btnCol.className = 'bm-btn-col';
    const addBtn = this.createButton(t('dialog.bookmark.createButton.label'), () => this.doAdd());
    addBtn.classList.add('dialog-btn-primary');
    const cancelBtn = this.createButton(t('dialog.bookmark.createButton.label.x14bc24'), () => this.hide());
    const moveBtn = this.createButton(t('dialog.bookmark.createButton.label.xd57835'), () => this.doMove());
    btnCol.appendChild(addBtn);
    btnCol.appendChild(cancelBtn);
    btnCol.appendChild(moveBtn);
    midRow.appendChild(btnCol);

    body.appendChild(midRow);

    // 아이콘 버튼 행 (이름 바꾸기, 삭제)
    const iconRow = document.createElement('div');
    iconRow.className = 'bm-icon-row';
    const renameBtn = document.createElement('button');
    renameBtn.className = 'bm-icon-btn';
    renameBtn.title = t('dialog.bookmark.renameBtn.tooltip');
    renameBtn.textContent = '✏';
    renameBtn.addEventListener('click', () => this.doRename());
    const deleteBtn = document.createElement('button');
    deleteBtn.className = 'bm-icon-btn';
    deleteBtn.title = t('dialog.bookmark.deleteBtn.tooltip');
    deleteBtn.textContent = '✕';
    deleteBtn.addEventListener('click', () => this.doDelete());
    iconRow.appendChild(renameBtn);
    iconRow.appendChild(deleteBtn);
    body.appendChild(iconRow);

    // 정렬 기준
    const sortRow = document.createElement('div');
    sortRow.className = 'bm-sort-row';
    const sortLabel = document.createElement('span');
    sortLabel.className = 'bm-label';
    sortLabel.textContent = t('dialog.bookmark.sortLabel.text');
    sortRow.appendChild(sortLabel);

    const radioName = document.createElement('label');
    radioName.className = 'bm-radio';
    const rName = document.createElement('input');
    rName.type = 'radio'; rName.name = 'bm-sort'; rName.value = 'name';
    rName.addEventListener('change', () => { this.sortMode = 'name'; this.refreshList(); });
    radioName.appendChild(rName);
    radioName.appendChild(document.createTextNode(t('dialog.bookmark.build.text')));

    const radioPos = document.createElement('label');
    radioPos.className = 'bm-radio';
    const rPos = document.createElement('input');
    rPos.type = 'radio'; rPos.name = 'bm-sort'; rPos.value = 'position'; rPos.checked = true;
    rPos.addEventListener('change', () => { this.sortMode = 'position'; this.refreshList(); });
    radioPos.appendChild(rPos);
    radioPos.appendChild(document.createTextNode(t('dialog.bookmark.build.text.xf5e9d1')));

    sortRow.appendChild(radioName);
    sortRow.appendChild(radioPos);
    body.appendChild(sortRow);

    this.dialog.appendChild(body);
    this.overlay.appendChild(this.dialog);
  }

  private createButton(text: string, handler: () => void): HTMLButtonElement {
    const btn = document.createElement('button');
    btn.className = 'dialog-btn';
    btn.textContent = text;
    btn.addEventListener('click', handler);
    return btn;
  }

  // ── 목록 갱신 ──

  private refreshList(): void {
    this.bookmarks = this.services.wasm.getBookmarks();
    if (this.sortMode === 'name') {
      this.bookmarks.sort((a, b) => a.name.localeCompare(b.name));
    }
    // position은 이미 문서 순서대로 반환됨

    this.listEl.replaceChildren();
    this.selectedIdx = -1;

    if (this.bookmarks.length === 0) {
      const empty = document.createElement('div');
      empty.className = 'bm-empty';
      empty.textContent = t('dialog.bookmark.empty.text');
      this.listEl.appendChild(empty);
      return;
    }

    for (let i = 0; i < this.bookmarks.length; i++) {
      const bm = this.bookmarks[i];
      const row = document.createElement('div');
      row.className = 'bm-item';
      const nameSpan = document.createElement('span');
      nameSpan.className = 'bm-item-name';
      nameSpan.textContent = bm.name || t('dialog.bookmark.nameSpan.text');
      const typeSpan = document.createElement('span');
      typeSpan.className = 'bm-item-type';
      typeSpan.textContent = t('dialog.bookmark.typeSpan.text');
      row.appendChild(nameSpan);
      row.appendChild(typeSpan);
      row.addEventListener('click', () => this.selectItem(i));
      row.addEventListener('dblclick', () => { this.selectItem(i); this.doMove(); });
      this.listEl.appendChild(row);
    }
  }

  private selectItem(idx: number): void {
    this.selectedIdx = idx;
    const items = this.listEl.querySelectorAll('.bm-item');
    items.forEach((el, i) => el.classList.toggle('selected', i === idx));
    if (idx >= 0 && idx < this.bookmarks.length) {
      this.nameInput.value = this.bookmarks[idx].name;
    }
    this.statusLabel.textContent = '';
  }

  // ── 이름 제안 ──

  private suggestName(): void {
    const ih = this.services.getInputHandler();
    if (!ih) return;
    // 기존 선택 텍스트나 커서 주변 텍스트를 기본 이름으로 제안
    const count = this.bookmarks.length + 1;
    this.nameInput.value = `책갈피${count}`;
  }

  // ── 동작 ──

  private doAdd(): void {
    const name = this.nameInput.value.trim();
    if (!name) {
      this.statusLabel.textContent = t('dialog.bookmark.statusLabel.text');
      this.statusLabel.style.color = '#c00';
      return;
    }
    if (name.length > MAX_BOOKMARK_NAME_LEN) {
      this.statusLabel.textContent = t('dialog.bookmark.statusLabel.text.x5fcb7e', { p1: MAX_BOOKMARK_NAME_LEN });
      this.statusLabel.style.color = '#c00';
      return;
    }

    const ih = this.services.getInputHandler();
    if (!ih) return;
    const pos = ih.getCursorPosition();

    // [책갈피 이관] 추가를 snapshot 으로 라우팅해 undo 가능(기존 emit-only → 되돌릴 수 없었음).
    let ok = false;
    let errMsg: string | undefined;
    ih.executeOperation({
      kind: 'snapshot',
      operationType: 'addBookmark',
      operation: (wasm) => {
        const r = wasm.addBookmark(pos.sectionIndex, pos.paragraphIndex, pos.charOffset, name);
        ok = r.ok;
        errMsg = r.error;
        return pos;
      },
    });

    if (ok) {
      this.hide();
    } else {
      this.statusLabel.style.color = '#c00';
      this.statusLabel.textContent = errMsg ?? t('dialog.bookmark.statusLabel.text.x31f4ef');
    }
  }

  private doMove(): void {
    if (this.selectedIdx < 0 || this.selectedIdx >= this.bookmarks.length) return;
    const bm = this.bookmarks[this.selectedIdx];
    const ih = this.services.getInputHandler();
    if (!ih) return;

    const tryMove = (s: number, p: number, o: number) =>
      ih.moveCursorTo({ sectionIndex: s, paragraphIndex: p, charOffset: o });

    if (!tryMove(bm.sec, bm.para, bm.charPos)) {
      // 표 문단 등 커서 이동 불가 → 인접 문단 탐색
      let moved = false;
      for (let d = 1; d <= 5 && !moved; d++) {
        if (tryMove(bm.sec, bm.para + d, 0)) { moved = true; break; }
        if (bm.para - d >= 0 && tryMove(bm.sec, bm.para - d, 0)) { moved = true; break; }
      }
    }
    this.hide();
  }

  private doDelete(): void {
    if (this.selectedIdx < 0 || this.selectedIdx >= this.bookmarks.length) return;
    const bm = this.bookmarks[this.selectedIdx];

    if (!confirm(t('dialog.bookmark.doDelete.message', { p1: bm.name }))) return;

    const ih = this.services.getInputHandler();
    if (!ih) return;
    // [책갈피 이관] 삭제를 snapshot 으로 라우팅.
    let ok = false;
    ih.executeOperation({
      kind: 'snapshot',
      operationType: 'deleteBookmark',
      operation: (wasm) => {
        ok = wasm.deleteBookmark(bm.sec, bm.para, bm.ctrlIdx).ok;
        return ih.getCursorPosition();
      },
    });
    if (ok) {
      this.refreshList();
      this.statusLabel.textContent = '';
    }
  }

  private doRename(): void {
    if (this.selectedIdx < 0 || this.selectedIdx >= this.bookmarks.length) return;
    const bm = this.bookmarks[this.selectedIdx];
    const newName = prompt('새 책갈피 이름:', bm.name);
    if (!newName || newName.trim() === '' || newName === bm.name) return;
    if (newName.trim().length > MAX_BOOKMARK_NAME_LEN) {
      alert(t('dialog.bookmark.doRename.message', { p1: MAX_BOOKMARK_NAME_LEN }));
      return;
    }

    const ih = this.services.getInputHandler();
    if (!ih) return;
    // [책갈피 이관] 이름 변경을 snapshot 으로 라우팅.
    let ok = false;
    let errMsg: string | undefined;
    ih.executeOperation({
      kind: 'snapshot',
      operationType: 'renameBookmark',
      operation: (wasm) => {
        const r = wasm.renameBookmark(bm.sec, bm.para, bm.ctrlIdx, newName.trim());
        ok = r.ok;
        errMsg = r.error;
        return ih.getCursorPosition();
      },
    });
    if (ok) {
      this.refreshList();
    } else {
      this.statusLabel.style.color = '#c00';
      this.statusLabel.textContent = errMsg ?? t('dialog.bookmark.statusLabel.text.x3ec6b4');
    }
  }
}
